# WordPress MySQL database migration
#
# Generated: Thursday 24. November 2016 15:29 UTC
# Hostname: localhost
# Database: `wordpresstest`
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `igefiefcfs_sessions`
#

DROP TABLE IF EXISTS `igefiefcfs_sessions`;


#
# Table structure of table `igefiefcfs_sessions`
#

CREATE TABLE `igefiefcfs_sessions` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `data` text,
  `expires` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `igefiefcfs_sessions`
#
INSERT INTO `igefiefcfs_sessions` ( `id`, `data`, `expires`) VALUES
('01812b49ce645715b58460fdf9a8f5b9', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480012608'),
('01a2af3793a8f39150ebc3972c7c9af2', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480014442'),
('01e49145d07fc27d012c101f286de55c', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480014507'),
('031c0ece5970c09ef2e5709f1d0395f7', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480012978'),
('03232487057694ed656d3b6cd11a7a19', 'a:7:{s:7:"post_id";i:21;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:2:{i:0;i:58;i:1;i:59;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1479957018'),
('043db41f0c04309b3fdb4e999804882b', 'a:7:{s:7:"post_id";i:21;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:58;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1479990761'),
('0ad113edb3720e79b3a1af54d0bfe24f', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480014494'),
('0b1b9a031ec64d3d5cde30e56907f501', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480012587'),
('12e03eb06935e2bbcf0509a94b4d59ba', 'a:7:{s:7:"post_id";i:21;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:58;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1479998404'),
('1438d7a52a1fbbcefe2a7540ad139763', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013476'),
('1591fe7f7a2614dd4cda4f8f0042997a', 'a:7:{s:7:"post_id";i:21;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:58;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1479990855'),
('17dd7fc5e6f1801102e955a6c49dab77', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013654'),
('18242e7aee9e28eed915a872d1515baa', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013435'),
('1abd9bba13a8c4f20f5c26acefb91b2a', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013541'),
('20650b4898a35c18f6dceb234cf70c9d', 'a:7:{s:7:"post_id";i:21;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:58;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1479998324'),
('22b81f1ddaf2ee2fac7b4fdd06d56b98', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480012752'),
('23b8d7b6df1d01996eeb56f064453471', 'a:7:{s:7:"post_id";i:21;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:58;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1479991603'),
('2a5471404ec6f07a609c94890bd10363', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480015118'),
('2dc3cbc54f13070fea072e73cdae6fb9', 'a:7:{s:7:"post_id";i:21;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:2:{i:0;i:58;i:1;i:59;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1479961099'),
('34b62c3f259c173e8689df387d4cfeaa', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480014975'),
('3631a91830272cace932c74b752c3ac9', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013767'),
('37b282db3c29ea396fcbb58bf27e8244', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480014356'),
('3f7af127227bb53a20e6511e2500bdb7', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013801'),
('4297df8504478713791e380eefb31a89', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013571'),
('44a0094298417bf123f0f6c58ece7a4b', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013242'),
('451eed36ab17b8e0dbda3a314a3a0d61', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480012254'),
('4926ffb8e64acf0dfbcd45263e03b451', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1479999400'),
('4c79e9c222e6dfe6b1aebe950068b2de', 'a:7:{s:7:"post_id";i:21;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:58;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1479998294'),
('4ce2cc2951eb1b857eb9522a6ef00844', 'a:7:{s:7:"post_id";i:21;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:2:{i:0;i:58;i:1;i:59;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1479955581'),
('50387222520426a5108100759c252114', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480014523'),
('55c1b71db968a31605cc274d8206dd73', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013342'),
('5a2fe524e456b1c02fca57362276311c', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480014961'),
('681569d655f5549725704b843bdee402', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013275'),
('6c47e43749c6859c64cefdc79fd07181', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013258'),
('735ee5f9564da9d3b0f6721f7f78640e', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013788'),
('7a617e8c3b9beb30546c202f8c14668f', 'a:7:{s:7:"post_id";i:21;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:2:{i:0;i:58;i:1;i:59;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1479956612'),
('7b2187ee5cbeadb07dbb4bc1b631b9f6', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013382'),
('7bf7ec8ace22499f56ccfb7da5307b06', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013180'),
('7c6f8db10b99f2520f3081b3fa6be2d5', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013668'),
('7f1f39b395926659b285406b8d5285b5', 'a:7:{s:7:"post_id";i:21;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:58;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1479961549'),
('80b80a255a80fc5bfdc3607af4aa6792', 'a:7:{s:7:"post_id";i:21;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:2:{i:0;i:58;i:1;i:59;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1479961250'),
('825cadee0f23728426e38acb05ef218b', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480012216'),
('8420a0864353401c528678e98511d8a2', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013814'),
('88718de512ee0a463465659cda8cc947', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013316'),
('8bd0978507a264340b8c17cdea0a406f', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480014239'),
('8c6d2b555711d0a417ed75421861adff', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480014824'),
('8da2352d61fcbb1310aeb2366fa96c80', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480014901'),
('8ea5fde2d871e22f35da8d373857b369', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013096'),
('920719c0b4ae460bbf88dcc5ebefd89e', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013746'),
('94ddf9f842be9d039293100ea21160f5', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480014413'),
('a393703db7c4c41e960f4a0475282027', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013204'),
('a4d63cc51bfb1f233de700ceb47e411f', 'a:7:{s:7:"post_id";i:21;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:58;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1479961884'),
('a6040ad0aa9a7a29346abe5f44a59fdf', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480012775'),
('a6da519d24d4c005d0258201b58a0499', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013704'),
('a75121ec5cdf109bf4427144dd46aef6', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013630'),
('a8fdad59c40c7c83942cabdf6cfef0a2', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480014560'),
('a91b425f8b32f30ba481f1fdfef2ed7e', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013687'),
('bc68b9becc248f876453f17cad9ab461', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480014471'),
('bd9dd922b85e3f7d6d2a01b14b348c83', 'a:7:{s:7:"post_id";i:21;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:58;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1479962275'),
('be5a4a485b52b928eccc268f60030b01', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013081'),
('c2efc0d3771dc248cb18356fcd85652d', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480014259'),
('c3b02f7d6deff19d12a2f1a67d281c9f', 'a:7:{s:7:"post_id";i:21;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:2:{i:0;i:58;i:1;i:59;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1479955518'),
('c7fe7eb20f4b13fdc42b46a94b656132', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013500'),
('c9e190720a5d192eb5ffdf77fda81aa8', 'a:7:{s:7:"post_id";i:21;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:58;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1479961593'),
('ca11e0a73ed0b754e91b28cf5b1acadd', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013597'),
('cec30fec86d3bb3cadfab1cc0d290011', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480012999'),
('df1b7e87166fde69289dcbd8bc920785', 'a:7:{s:7:"post_id";i:21;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:2:{i:0;i:58;i:1;i:59;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1479955371'),
('e360dbf22cb8fc216816e4e1d20e876c', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480014378'),
('e43d77c58a8976ca356140b8ee5ee5d0', 'a:7:{s:7:"post_id";i:21;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:2:{i:0;i:58;i:1;i:59;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1479955557'),
('e980b164a11ab16bb1308dafbd68e6f0', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480015206'),
('ec3c916e96de7d3da32d5599e8af9039', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480012154'),
('f090c617add739148cb386aaad24b1d6', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013523'),
('f28bf401d03de30b99d224eb115c72f8', 'a:7:{s:7:"post_id";i:21;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:2:{i:0;i:58;i:1;i:59;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1479955412'),
('f424362a6bef62d86ade6ec234dcb2db', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480014204'),
('f5ef7ddb43b1184bc4e01c15e255c509', 'a:7:{s:7:"post_id";i:21;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:58;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1479998288'),
('fddbbbe966329a88ca7268878d1ca0b9', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480014186'),
('ffeb0d6fb8cb3e078689cfabdec739b8', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:8;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1480013222') ;

#
# End of data contents of table `igefiefcfs_sessions`
# --------------------------------------------------------



#
# Delete any existing table `igefiefcfs_values`
#

DROP TABLE IF EXISTS `igefiefcfs_values`;


#
# Table structure of table `igefiefcfs_values`
#

CREATE TABLE `igefiefcfs_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `field_id` int(10) unsigned DEFAULT NULL,
  `meta_id` int(10) unsigned DEFAULT NULL,
  `post_id` int(10) unsigned DEFAULT NULL,
  `base_field_id` int(10) unsigned DEFAULT '0',
  `hierarchy` text,
  `depth` int(10) unsigned DEFAULT '0',
  `weight` int(10) unsigned DEFAULT '0',
  `sub_weight` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `field_id_idx` (`field_id`),
  KEY `post_id_idx` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;


#
# Data contents of table `igefiefcfs_values`
#
INSERT INTO `igefiefcfs_values` ( `id`, `field_id`, `meta_id`, `post_id`, `base_field_id`, `hierarchy`, `depth`, `weight`, `sub_weight`) VALUES
(8, 1, 328, 10, 0, '', 0, 0, 0),
(9, 1, 364, 86, 0, '', 0, 0, 0),
(10, 1, 368, 103, 0, '', 0, 0, 0),
(11, 1, 372, 104, 0, '', 0, 0, 0),
(12, 1, 376, 105, 0, '', 0, 0, 0),
(13, 1, 380, 106, 0, '', 0, 0, 0),
(14, 1, 384, 107, 0, '', 0, 0, 0),
(15, 1, 388, 108, 0, '', 0, 0, 0),
(16, 1, 392, 109, 0, '', 0, 0, 0),
(17, 1, 396, 110, 0, '', 0, 0, 0),
(19, 1, 401, 112, 0, '', 0, 0, 0),
(20, 1, 405, 113, 0, '', 0, 0, 0),
(21, 1, 409, 114, 0, '', 0, 0, 0),
(22, 1, 411, 115, 0, '', 0, 0, 0),
(23, 1, 417, 116, 0, '', 0, 0, 0),
(24, 1, 419, 81, 0, '', 0, 0, 0),
(34, 3, 438, 21, 0, '', 0, 0, 0),
(35, 4, 439, 21, 0, '', 0, 0, 0),
(36, 2, 443, 21, 0, '', 0, 0, 0),
(37, 5, 444, 21, 0, '', 0, 0, 0),
(38, 6, 445, 21, 0, '', 0, 0, 0) ;

#
# End of data contents of table `igefiefcfs_values`
# --------------------------------------------------------



#
# Delete any existing table `igefiefcommentmeta`
#

DROP TABLE IF EXISTS `igefiefcommentmeta`;


#
# Table structure of table `igefiefcommentmeta`
#

CREATE TABLE `igefiefcommentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `igefiefcommentmeta`
#

#
# End of data contents of table `igefiefcommentmeta`
# --------------------------------------------------------



#
# Delete any existing table `igefiefcomments`
#

DROP TABLE IF EXISTS `igefiefcomments`;


#
# Table structure of table `igefiefcomments`
#

CREATE TABLE `igefiefcomments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `igefiefcomments`
#
INSERT INTO `igefiefcomments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2016-11-07 09:23:56', '2016-11-07 09:23:56', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, 'post-trashed', '', '', 0, 0) ;

#
# End of data contents of table `igefiefcomments`
# --------------------------------------------------------



#
# Delete any existing table `igefieflinks`
#

DROP TABLE IF EXISTS `igefieflinks`;


#
# Table structure of table `igefieflinks`
#

CREATE TABLE `igefieflinks` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `igefieflinks`
#

#
# End of data contents of table `igefieflinks`
# --------------------------------------------------------



#
# Delete any existing table `igefiefoptions`
#

DROP TABLE IF EXISTS `igefiefoptions`;


#
# Table structure of table `igefiefoptions`
#

CREATE TABLE `igefiefoptions` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=615 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `igefiefoptions`
#
INSERT INTO `igefiefoptions` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/student', 'yes'),
(2, 'home', 'http://localhost/student', 'yes'),
(3, 'blogname', 'inhabitent', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'kiana.aghaei@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '16', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:133:{s:10:"Product/?$";s:27:"index.php?post_type=product";s:40:"Product/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:35:"Product/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:27:"Product/page/([0-9]{1,})/?$";s:45:"index.php?post_type=product&paged=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:35:"product/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"product/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"product/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"product/([^/]+)/embed/?$";s:40:"index.php?product=$matches[1]&embed=true";s:28:"product/([^/]+)/trackback/?$";s:34:"index.php?product=$matches[1]&tb=1";s:48:"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:43:"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:36:"product/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&paged=$matches[2]";s:43:"product/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&cpage=$matches[2]";s:32:"product/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?product=$matches[1]&page=$matches[2]";s:24:"product/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"product/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"product/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"product_type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?product_type=$matches[1]&feed=$matches[2]";s:48:"product_type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?product_type=$matches[1]&feed=$matches[2]";s:29:"product_type/([^/]+)/embed/?$";s:45:"index.php?product_type=$matches[1]&embed=true";s:41:"product_type/([^/]+)/page/?([0-9]{1,})/?$";s:52:"index.php?product_type=$matches[1]&paged=$matches[2]";s:23:"product_type/([^/]+)/?$";s:34:"index.php?product_type=$matches[1]";s:31:"cfs/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:41:"cfs/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:61:"cfs/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"cfs/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"cfs/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:37:"cfs/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:20:"cfs/([^/]+)/embed/?$";s:51:"index.php?post_type=cfs&name=$matches[1]&embed=true";s:24:"cfs/([^/]+)/trackback/?$";s:45:"index.php?post_type=cfs&name=$matches[1]&tb=1";s:32:"cfs/([^/]+)/page/?([0-9]{1,})/?$";s:58:"index.php?post_type=cfs&name=$matches[1]&paged=$matches[2]";s:39:"cfs/([^/]+)/comment-page-([0-9]{1,})/?$";s:58:"index.php?post_type=cfs&name=$matches[1]&cpage=$matches[2]";s:28:"cfs/([^/]+)(?:/([0-9]+))?/?$";s:57:"index.php?post_type=cfs&name=$matches[1]&page=$matches[2]";s:20:"cfs/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:30:"cfs/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:50:"cfs/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:"cfs/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:"cfs/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:"cfs/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=12&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:8:{i:0;s:47:"business-hours-widget/business-hours-widget.php";i:1;s:36:"contact-form-7/wp-contact-form-7.php";i:2;s:26:"custom-field-suite/cfs.php";i:3;s:23:"debug-bar/debug-bar.php";i:4;s:53:"inhabitent-functionality/inhabitent-functionality.php";i:5;s:19:"rest-api/plugin.php";i:6;s:27:"theme-check/theme-check.php";i:7;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:3:{i:0;s:72:"/Applications/MAMP/htdocs/student/wp-content/themes/inhabitent/style.css";i:1;s:79:"/Applications/MAMP/htdocs/student/wp-content/plugins/custom-field-suite/cfs.php";i:2;s:0:"";}', 'no'),
(40, 'template', 'inhabitent', 'yes'),
(41, 'stylesheet', 'inhabitent', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '37965', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:3:{i:1;a:0:{}i:2;a:3:{s:5:"title";s:12:"Contact Info";s:4:"text";s:252:"<i class="fa fa-phone" aria-hidden="true"></i><a>  778-456-7891</a><br>\r\n\r\n<i class="fa fa-envelope" aria-hidden="true"></i></i><a> info@inhabitent.com</a><br>\r\n\r\n<i class="fa fa-map-marker" aria-hidden="true"></i>1490 W Broadway\r\nVancouver, BC V6H 1H5";s:6:"filter";b:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '16', 'yes'),
(84, 'page_on_front', '12', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '37965', 'yes'),
(92, 'igefiefuser_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:18:"view_query_monitor";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_archives', 'a:3:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}i:3;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'sidebars_widgets', 'a:4:{s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:6:"text-2";i:1;s:23:"business-hours-widget-3";i:2;s:10:"archives-3";}s:13:"array_version";i:3;}', 'yes'),
(99, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(101, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `igefiefoptions` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(103, 'cron', 'a:4:{i:1480014257;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1480022636;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1480065845;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(106, 'nonce_key', '3HC]<D}1jzV}0_pFe4HLRbN13O;+x$2K.xW|Zfl7umt2cp<oEC}o6 I)Md6XKf/7', 'no'),
(107, 'nonce_salt', 'HoBk<q~X~>Be#{#-xP;!;7@$4*?fr021b&t07])kU5~k_]w0b44~Vd8Di*N0psLh', 'no'),
(108, 'logged_in_key', '`Z~_#QU~mWec>6uF@j$ )7neJ-N`.qG XaxH0geXt;{Q%@y7_pRE/{,z. zyF5bE', 'no'),
(109, 'logged_in_salt', '0$al}wA9LaoAYqx-W)_kIw&Irx%@ F{N`d!**|@9kk#KH+Q&+HIC>  in_Ke;@[Y', 'no'),
(117, 'auth_key', '4]X@M|6H=uaG_Fs!Bh%k8dx9En0Q!)48fq-tl]OVBfnP%ZMP(F&rB?Hs4RE6*-@,', 'no'),
(118, 'auth_salt', '^4~hr3La~F_xRjS4u(6JSXG fzxJd8U mrv*=;F=w:i5:7^IIv}=VTlUzQq.j<_e', 'no'),
(122, 'can_compress_scripts', '1', 'no'),
(139, 'theme_mods_twentysixteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1478510954;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(140, 'current_theme', 'Inhabitent', 'yes'),
(141, 'theme_mods_inhabitent', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:7:"primary";i:2;}}', 'yes'),
(142, 'theme_switched', '', 'yes'),
(144, 'recently_activated', 'a:0:{}', 'yes'),
(159, 'WPLANG', '', 'yes'),
(179, 'cfs_next_field_id', '7', 'yes'),
(180, 'cfs_version', '2.5.7', 'yes'),
(216, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:1:{i:0;i:2;}}', 'yes'),
(311, 'wpcf7', 'a:2:{s:7:"version";s:5:"4.5.1";s:13:"bulk_validate";a:4:{s:9:"timestamp";i:1478664196;s:7:"version";s:5:"4.5.1";s:11:"count_valid";i:1;s:13:"count_invalid";i:0;}}', 'yes'),
(334, 'widget_business-hours-widget', 'a:2:{i:3;a:4:{s:5:"title";s:14:"Business Hours";s:13:"monday_friday";s:10:"9am to 5pm";s:8:"saturday";s:13:"10am to 2 pm ";s:6:"sunday";s:6:"Closed";}s:12:"_multiwidget";i:1;}', 'yes'),
(481, 'upload_path', '', 'yes'),
(482, 'upload_url_path', '', 'yes'),
(586, 'category_children', 'a:0:{}', 'yes') ;

#
# End of data contents of table `igefiefoptions`
# --------------------------------------------------------



#
# Delete any existing table `igefiefpostmeta`
#

DROP TABLE IF EXISTS `igefiefpostmeta`;


#
# Table structure of table `igefiefpostmeta`
#

CREATE TABLE `igefiefpostmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=451 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `igefiefpostmeta`
#
INSERT INTO `igefiefpostmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(4, 8, '_edit_last', '1'),
(5, 8, '_edit_lock', '1478659783:1'),
(6, 8, 'cfs_fields', 'a:1:{i:0;a:8:{s:2:"id";i:1;s:4:"name";s:13:"product_price";s:5:"label";s:13:"Product Price";s:4:"type";s:4:"text";s:5:"notes";s:68:"write the price below. Please include the dollar sign if necessary. ";s:9:"parent_id";i:0;s:6:"weight";i:0;s:7:"options";a:2:{s:13:"default_value";s:0:"";s:8:"required";s:1:"1";}}}'),
(7, 8, 'cfs_rules', 'a:1:{s:10:"post_types";a:2:{s:8:"operator";s:2:"==";s:6:"values";a:1:{i:0;s:7:"product";}}}'),
(8, 8, 'cfs_extras', 'a:3:{s:5:"order";s:1:"0";s:7:"context";s:4:"side";s:11:"hide_editor";s:1:"0";}'),
(9, 10, '_edit_last', '1'),
(10, 10, '_edit_lock', '1479987022:1'),
(12, 12, '_edit_last', '1'),
(13, 12, '_edit_lock', '1478806426:1'),
(14, 16, '_edit_last', '1'),
(15, 16, '_edit_lock', '1478558044:1'),
(16, 2, '_wp_trash_meta_status', 'publish'),
(17, 2, '_wp_trash_meta_time', '1478558226'),
(18, 2, '_wp_desired_post_slug', 'sample-page'),
(19, 1, '_edit_lock', '1478558172:1'),
(20, 21, '_edit_last', '1'),
(21, 21, '_edit_lock', '1479984626:1'),
(22, 23, '_edit_last', '1'),
(23, 23, '_edit_lock', '1479099097:1'),
(24, 25, '_menu_item_type', 'post_type'),
(25, 25, '_menu_item_menu_item_parent', '0'),
(26, 25, '_menu_item_object_id', '12'),
(27, 25, '_menu_item_object', 'page'),
(28, 25, '_menu_item_target', ''),
(29, 25, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(30, 25, '_menu_item_xfn', ''),
(31, 25, '_menu_item_url', ''),
(32, 25, '_menu_item_orphaned', '1478565102'),
(33, 26, '_menu_item_type', 'post_type'),
(34, 26, '_menu_item_menu_item_parent', '0'),
(35, 26, '_menu_item_object_id', '21'),
(36, 26, '_menu_item_object', 'page'),
(37, 26, '_menu_item_target', ''),
(38, 26, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(39, 26, '_menu_item_xfn', ''),
(40, 26, '_menu_item_url', ''),
(41, 26, '_menu_item_orphaned', '1478565102'),
(42, 27, '_menu_item_type', 'post_type'),
(43, 27, '_menu_item_menu_item_parent', '0'),
(44, 27, '_menu_item_object_id', '23'),
(45, 27, '_menu_item_object', 'page'),
(46, 27, '_menu_item_target', ''),
(47, 27, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(48, 27, '_menu_item_xfn', ''),
(49, 27, '_menu_item_url', ''),
(50, 27, '_menu_item_orphaned', '1478565102'),
(51, 28, '_menu_item_type', 'post_type'),
(52, 28, '_menu_item_menu_item_parent', '0'),
(53, 28, '_menu_item_object_id', '12'),
(54, 28, '_menu_item_object', 'page'),
(55, 28, '_menu_item_target', ''),
(56, 28, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(57, 28, '_menu_item_xfn', ''),
(58, 28, '_menu_item_url', ''),
(59, 28, '_menu_item_orphaned', '1478565102'),
(60, 29, '_menu_item_type', 'post_type'),
(61, 29, '_menu_item_menu_item_parent', '0'),
(62, 29, '_menu_item_object_id', '16'),
(63, 29, '_menu_item_object', 'page'),
(64, 29, '_menu_item_target', ''),
(65, 29, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(66, 29, '_menu_item_xfn', ''),
(67, 29, '_menu_item_url', ''),
(68, 29, '_menu_item_orphaned', '1478565102'),
(69, 30, '_menu_item_type', 'post_type'),
(70, 30, '_menu_item_menu_item_parent', '0'),
(71, 30, '_menu_item_object_id', '12'),
(72, 30, '_menu_item_object', 'page'),
(73, 30, '_menu_item_target', ''),
(74, 30, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(75, 30, '_menu_item_xfn', ''),
(76, 30, '_menu_item_url', ''),
(77, 30, '_menu_item_orphaned', '1478565260'),
(78, 31, '_menu_item_type', 'post_type'),
(79, 31, '_menu_item_menu_item_parent', '0'),
(80, 31, '_menu_item_object_id', '21'),
(81, 31, '_menu_item_object', 'page'),
(82, 31, '_menu_item_target', ''),
(83, 31, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(84, 31, '_menu_item_xfn', ''),
(85, 31, '_menu_item_url', ''),
(86, 31, '_menu_item_orphaned', '1478565260'),
(87, 32, '_menu_item_type', 'post_type'),
(88, 32, '_menu_item_menu_item_parent', '0'),
(89, 32, '_menu_item_object_id', '23'),
(90, 32, '_menu_item_object', 'page'),
(91, 32, '_menu_item_target', ''),
(92, 32, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(93, 32, '_menu_item_xfn', ''),
(94, 32, '_menu_item_url', ''),
(95, 32, '_menu_item_orphaned', '1478565260'),
(96, 33, '_menu_item_type', 'post_type'),
(97, 33, '_menu_item_menu_item_parent', '0'),
(98, 33, '_menu_item_object_id', '12'),
(99, 33, '_menu_item_object', 'page'),
(100, 33, '_menu_item_target', ''),
(101, 33, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(102, 33, '_menu_item_xfn', ''),
(103, 33, '_menu_item_url', '') ;
INSERT INTO `igefiefpostmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(104, 33, '_menu_item_orphaned', '1478565260'),
(105, 34, '_menu_item_type', 'post_type'),
(106, 34, '_menu_item_menu_item_parent', '0'),
(107, 34, '_menu_item_object_id', '16'),
(108, 34, '_menu_item_object', 'page'),
(109, 34, '_menu_item_target', ''),
(110, 34, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(111, 34, '_menu_item_xfn', ''),
(112, 34, '_menu_item_url', ''),
(113, 34, '_menu_item_orphaned', '1478565260'),
(114, 35, '_menu_item_type', 'post_type'),
(115, 35, '_menu_item_menu_item_parent', '0'),
(116, 35, '_menu_item_object_id', '12'),
(117, 35, '_menu_item_object', 'page'),
(118, 35, '_menu_item_target', ''),
(119, 35, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(120, 35, '_menu_item_xfn', ''),
(121, 35, '_menu_item_url', ''),
(122, 35, '_menu_item_orphaned', '1478565352'),
(123, 36, '_menu_item_type', 'post_type'),
(124, 36, '_menu_item_menu_item_parent', '0'),
(125, 36, '_menu_item_object_id', '21'),
(126, 36, '_menu_item_object', 'page'),
(127, 36, '_menu_item_target', ''),
(128, 36, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(129, 36, '_menu_item_xfn', ''),
(130, 36, '_menu_item_url', ''),
(131, 36, '_menu_item_orphaned', '1478565352'),
(132, 37, '_menu_item_type', 'post_type'),
(133, 37, '_menu_item_menu_item_parent', '0'),
(134, 37, '_menu_item_object_id', '23'),
(135, 37, '_menu_item_object', 'page'),
(136, 37, '_menu_item_target', ''),
(137, 37, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(138, 37, '_menu_item_xfn', ''),
(139, 37, '_menu_item_url', ''),
(140, 37, '_menu_item_orphaned', '1478565352'),
(141, 38, '_menu_item_type', 'post_type'),
(142, 38, '_menu_item_menu_item_parent', '0'),
(143, 38, '_menu_item_object_id', '12'),
(144, 38, '_menu_item_object', 'page'),
(145, 38, '_menu_item_target', ''),
(146, 38, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(147, 38, '_menu_item_xfn', ''),
(148, 38, '_menu_item_url', ''),
(149, 38, '_menu_item_orphaned', '1478565352'),
(150, 39, '_menu_item_type', 'post_type'),
(151, 39, '_menu_item_menu_item_parent', '0'),
(152, 39, '_menu_item_object_id', '16'),
(153, 39, '_menu_item_object', 'page'),
(154, 39, '_menu_item_target', ''),
(155, 39, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(156, 39, '_menu_item_xfn', ''),
(157, 39, '_menu_item_url', ''),
(158, 39, '_menu_item_orphaned', '1478565352'),
(159, 40, '_menu_item_type', 'post_type'),
(160, 40, '_menu_item_menu_item_parent', '0'),
(161, 40, '_menu_item_object_id', '12'),
(162, 40, '_menu_item_object', 'page'),
(163, 40, '_menu_item_target', ''),
(164, 40, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(165, 40, '_menu_item_xfn', ''),
(166, 40, '_menu_item_url', ''),
(167, 40, '_menu_item_orphaned', '1478568753'),
(168, 41, '_menu_item_type', 'post_type'),
(169, 41, '_menu_item_menu_item_parent', '0'),
(170, 41, '_menu_item_object_id', '21'),
(171, 41, '_menu_item_object', 'page'),
(172, 41, '_menu_item_target', ''),
(173, 41, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(174, 41, '_menu_item_xfn', ''),
(175, 41, '_menu_item_url', ''),
(176, 41, '_menu_item_orphaned', '1478568753'),
(177, 42, '_menu_item_type', 'post_type'),
(178, 42, '_menu_item_menu_item_parent', '0'),
(179, 42, '_menu_item_object_id', '23'),
(180, 42, '_menu_item_object', 'page'),
(181, 42, '_menu_item_target', ''),
(182, 42, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(183, 42, '_menu_item_xfn', ''),
(184, 42, '_menu_item_url', ''),
(185, 42, '_menu_item_orphaned', '1478568753'),
(186, 43, '_menu_item_type', 'post_type'),
(187, 43, '_menu_item_menu_item_parent', '0'),
(188, 43, '_menu_item_object_id', '12'),
(189, 43, '_menu_item_object', 'page'),
(190, 43, '_menu_item_target', ''),
(191, 43, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(192, 43, '_menu_item_xfn', ''),
(193, 43, '_menu_item_url', ''),
(194, 43, '_menu_item_orphaned', '1478568753'),
(195, 44, '_menu_item_type', 'post_type'),
(196, 44, '_menu_item_menu_item_parent', '0'),
(197, 44, '_menu_item_object_id', '16'),
(198, 44, '_menu_item_object', 'page'),
(199, 44, '_menu_item_target', ''),
(200, 44, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(201, 44, '_menu_item_xfn', ''),
(202, 44, '_menu_item_url', ''),
(203, 44, '_menu_item_orphaned', '1478568753') ;
INSERT INTO `igefiefpostmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(213, 46, '_menu_item_type', 'post_type'),
(214, 46, '_menu_item_menu_item_parent', '0'),
(215, 46, '_menu_item_object_id', '21'),
(216, 46, '_menu_item_object', 'page'),
(217, 46, '_menu_item_target', ''),
(218, 46, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(219, 46, '_menu_item_xfn', ''),
(220, 46, '_menu_item_url', ''),
(222, 47, '_menu_item_type', 'post_type'),
(223, 47, '_menu_item_menu_item_parent', '0'),
(224, 47, '_menu_item_object_id', '23'),
(225, 47, '_menu_item_object', 'page'),
(226, 47, '_menu_item_target', ''),
(227, 47, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(228, 47, '_menu_item_xfn', ''),
(229, 47, '_menu_item_url', ''),
(231, 48, '_menu_item_type', 'post_type'),
(232, 48, '_menu_item_menu_item_parent', '0'),
(233, 48, '_menu_item_object_id', '12'),
(234, 48, '_menu_item_object', 'page'),
(235, 48, '_menu_item_target', ''),
(236, 48, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(237, 48, '_menu_item_xfn', ''),
(238, 48, '_menu_item_url', ''),
(239, 48, '_menu_item_orphaned', '1478568830'),
(240, 49, '_menu_item_type', 'post_type'),
(241, 49, '_menu_item_menu_item_parent', '0'),
(242, 49, '_menu_item_object_id', '16'),
(243, 49, '_menu_item_object', 'page'),
(244, 49, '_menu_item_target', ''),
(245, 49, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(246, 49, '_menu_item_xfn', ''),
(247, 49, '_menu_item_url', ''),
(249, 50, '_edit_last', '1'),
(250, 50, '_edit_lock', '1479984739:1'),
(251, 51, '_wp_attached_file', '2016/11/van-camper-1.jpg'),
(252, 51, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1026;s:4:"file";s:24:"2016/11/van-camper-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"van-camper-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"van-camper-1-300x205.jpg";s:5:"width";i:300;s:6:"height";i:205;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"van-camper-1-768x525.jpg";s:5:"width";i:768;s:6:"height";i:525;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"van-camper-1-1024x700.jpg";s:5:"width";i:1024;s:6:"height";i:700;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(253, 50, '_thumbnail_id', '51'),
(255, 56, '_wp_attached_file', '2016/11/warm-cocktail-1.jpg'),
(256, 56, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:27:"2016/11/warm-cocktail-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"warm-cocktail-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"warm-cocktail-1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"warm-cocktail-1-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"warm-cocktail-1-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(257, 55, '_edit_last', '1'),
(258, 55, '_edit_lock', '1479984705:1'),
(259, 55, '_thumbnail_id', '56'),
(261, 58, '_edit_last', '1'),
(262, 58, '_edit_lock', '1479946995:1'),
(263, 58, 'cfs_fields', 'a:3:{i:0;a:8:{s:2:"id";s:1:"2";s:4:"name";s:23:"aboout_background_image";s:5:"label";s:16:"background image";s:4:"type";s:4:"file";s:5:"notes";s:27:"upload image on your choice";s:9:"parent_id";i:0;s:6:"weight";i:0;s:7:"options";a:3:{s:9:"file_type";s:5:"image";s:12:"return_value";s:3:"url";s:8:"required";s:1:"0";}}i:1;a:8:{s:2:"id";i:5;s:4:"name";s:9:"our_story";s:5:"label";s:9:"Our Story";s:4:"type";s:7:"wysiwyg";s:5:"notes";s:0:"";s:9:"parent_id";i:0;s:6:"weight";i:1;s:7:"options";a:2:{s:10:"formatting";s:4:"none";s:8:"required";s:1:"1";}}i:2;a:8:{s:2:"id";i:6;s:4:"name";s:8:"our_team";s:5:"label";s:8:"Our Team";s:4:"type";s:7:"wysiwyg";s:5:"notes";s:0:"";s:9:"parent_id";i:0;s:6:"weight";i:2;s:7:"options";a:2:{s:10:"formatting";s:4:"none";s:8:"required";s:1:"1";}}}'),
(264, 58, 'cfs_rules', 'a:1:{s:14:"page_templates";a:2:{s:8:"operator";s:2:"==";s:6:"values";a:1:{i:0;s:9:"about.php";}}}'),
(265, 58, 'cfs_extras', 'a:3:{s:5:"order";s:1:"0";s:7:"context";s:6:"normal";s:11:"hide_editor";s:1:"1";}'),
(266, 59, '_edit_last', '1'),
(267, 59, '_edit_lock', '1479946895:1'),
(269, 21, '_wp_page_template', 'about.php'),
(270, 60, '_wp_attached_file', '2016/11/about-hero.jpg'),
(271, 60, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:4000;s:6:"height";i:2667;s:4:"file";s:22:"2016/11/about-hero.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"about-hero-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"about-hero-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"about-hero-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"about-hero-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(273, 59, 'cfs_fields', 'a:2:{i:0;a:8:{s:2:"id";s:1:"3";s:4:"name";s:9:"our_story";s:5:"label";s:9:"Our Story";s:4:"type";s:4:"text";s:5:"notes";s:19:"what is your story?";s:9:"parent_id";i:0;s:6:"weight";i:0;s:7:"options";a:2:{s:13:"default_value";s:0:"";s:8:"required";s:1:"1";}}i:1;a:8:{s:2:"id";s:1:"4";s:4:"name";s:8:"our_team";s:5:"label";s:8:"Our Team";s:4:"type";s:4:"text";s:5:"notes";s:23:"what does your team do?";s:9:"parent_id";i:0;s:6:"weight";i:1;s:7:"options";a:2:{s:13:"default_value";s:0:"";s:8:"required";s:1:"1";}}}'),
(274, 59, 'cfs_rules', 'a:1:{s:14:"page_templates";a:2:{s:8:"operator";s:2:"==";s:6:"values";a:1:{i:0;s:9:"about.php";}}}'),
(275, 59, 'cfs_extras', 'a:3:{s:5:"order";s:1:"0";s:7:"context";s:6:"normal";s:11:"hide_editor";s:1:"0";}'),
(280, 64, '_wp_attached_file', '2016/11/about-hero.jpg'),
(281, 64, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:4000;s:6:"height";i:2667;s:4:"file";s:22:"2016/11/about-hero.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"about-hero-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"about-hero-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"about-hero-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"about-hero-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(282, 66, '_edit_last', '1'),
(283, 66, '_edit_lock', '1479984794:1'),
(284, 67, '_wp_attached_file', '2016/11/healthy-camp-food-1.jpg'),
(285, 67, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:31:"2016/11/healthy-camp-food-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"healthy-camp-food-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"healthy-camp-food-1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:31:"healthy-camp-food-1-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:32:"healthy-camp-food-1-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(286, 66, '_thumbnail_id', '67'),
(288, 70, '_edit_last', '1'),
(289, 70, '_edit_lock', '1479984845:1'),
(290, 71, '_wp_attached_file', '2016/11/solo-camping-1.jpg'),
(291, 71, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2515;s:6:"height";i:1830;s:4:"file";s:26:"2016/11/solo-camping-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"solo-camping-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"solo-camping-1-300x218.jpg";s:5:"width";i:300;s:6:"height";i:218;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:26:"solo-camping-1-768x559.jpg";s:5:"width";i:768;s:6:"height";i:559;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:27:"solo-camping-1-1024x745.jpg";s:5:"width";i:1024;s:6:"height";i:745;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(292, 70, '_thumbnail_id', '71'),
(294, 73, '_edit_last', '1'),
(295, 73, '_edit_lock', '1479984820:1'),
(296, 73, '_thumbnail_id', '76'),
(299, 75, '_edit_last', '1'),
(300, 75, '_edit_lock', '1478659321:1'),
(301, 76, '_wp_attached_file', '2016/11/glamping-1.jpg'),
(302, 76, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:22:"2016/11/glamping-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"glamping-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"glamping-1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"glamping-1-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"glamping-1-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(304, 75, '_wp_trash_meta_status', 'draft'),
(305, 75, '_wp_trash_meta_time', '1478659447'),
(306, 75, '_wp_desired_post_slug', ''),
(308, 1, '_wp_trash_meta_status', 'publish'),
(309, 1, '_wp_trash_meta_time', '1478659554'),
(310, 1, '_wp_desired_post_slug', 'hello-world'),
(311, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}'),
(312, 80, '_menu_item_type', 'post_type_archive'),
(313, 80, '_menu_item_menu_item_parent', '0'),
(314, 80, '_menu_item_object_id', '-21'),
(315, 80, '_menu_item_object', 'product'),
(316, 80, '_menu_item_target', ''),
(317, 80, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(318, 80, '_menu_item_xfn', ''),
(319, 80, '_menu_item_url', ''),
(321, 81, '_edit_last', '1'),
(322, 81, '_edit_lock', '1479987010:1'),
(324, 82, '_wp_attached_file', '2016/11/beach-tent.jpg'),
(325, 82, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1950;s:4:"file";s:22:"2016/11/beach-tent.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"beach-tent-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"beach-tent-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"beach-tent-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"beach-tent-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(326, 84, '_wp_attached_file', '2016/11/camper-van.jpg'),
(327, 84, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1125;s:4:"file";s:22:"2016/11/camper-van.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"camper-van-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"camper-van-300x169.jpg";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"camper-van-768x432.jpg";s:5:"width";i:768;s:6:"height";i:432;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"camper-van-1024x576.jpg";s:5:"width";i:1024;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(328, 10, 'product_price', '$2500.00'),
(329, 10, '_thumbnail_id', '84'),
(330, 86, '_edit_last', '1'),
(331, 86, '_edit_lock', '1479986997:1') ;
INSERT INTO `igefiefpostmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(332, 87, '_wp_attached_file', '2016/11/weathered-canoes.jpg'),
(333, 87, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:28:"2016/11/weathered-canoes.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"weathered-canoes-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"weathered-canoes-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:28:"weathered-canoes-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:29:"weathered-canoes-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(334, 88, '_wp_attached_file', '2016/11/wood-ax.jpg'),
(335, 88, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:19:"2016/11/wood-ax.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"wood-ax-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"wood-ax-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:19:"wood-ax-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:20:"wood-ax-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(336, 89, '_wp_attached_file', '2016/11/leather-satchel.jpg'),
(337, 89, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:27:"2016/11/leather-satchel.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"leather-satchel-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"leather-satchel-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"leather-satchel-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"leather-satchel-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(338, 90, '_wp_attached_file', '2016/11/nylon-tents.jpg'),
(339, 90, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1732;s:4:"file";s:23:"2016/11/nylon-tents.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"nylon-tents-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"nylon-tents-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"nylon-tents-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"nylon-tents-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(340, 91, '_wp_attached_file', '2016/11/rustic-tools.jpg'),
(341, 91, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:2111;s:4:"file";s:24:"2016/11/rustic-tools.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"rustic-tools-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"rustic-tools-300x244.jpg";s:5:"width";i:300;s:6:"height";i:244;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"rustic-tools-768x624.jpg";s:5:"width";i:768;s:6:"height";i:624;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"rustic-tools-1024x831.jpg";s:5:"width";i:1024;s:6:"height";i:831;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(342, 92, '_wp_attached_file', '2016/11/stew-can.jpg'),
(343, 92, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:20:"2016/11/stew-can.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"stew-can-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"stew-can-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"stew-can-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"stew-can-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(344, 93, '_wp_attached_file', '2016/11/travel-hammock.jpg'),
(345, 93, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2288;s:6:"height";i:1520;s:4:"file";s:26:"2016/11/travel-hammock.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"travel-hammock-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"travel-hammock-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:26:"travel-hammock-768x510.jpg";s:5:"width";i:768;s:6:"height";i:510;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:27:"travel-hammock-1024x680.jpg";s:5:"width";i:1024;s:6:"height";i:680;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(346, 94, '_wp_attached_file', '2016/11/hand-knit-toque.jpg'),
(347, 94, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1845;s:4:"file";s:27:"2016/11/hand-knit-toque.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"hand-knit-toque-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"hand-knit-toque-300x213.jpg";s:5:"width";i:300;s:6:"height";i:213;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"hand-knit-toque-768x545.jpg";s:5:"width";i:768;s:6:"height";i:545;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"hand-knit-toque-1024x727.jpg";s:5:"width";i:1024;s:6:"height";i:727;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(348, 95, '_wp_attached_file', '2016/11/hiking-boots.jpg'),
(349, 95, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2376;s:6:"height";i:1782;s:4:"file";s:24:"2016/11/hiking-boots.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"hiking-boots-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"hiking-boots-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"hiking-boots-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"hiking-boots-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(350, 96, '_wp_attached_file', '2016/11/large-thermos.jpg'),
(351, 96, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1722;s:4:"file";s:25:"2016/11/large-thermos.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"large-thermos-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"large-thermos-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"large-thermos-768x509.jpg";s:5:"width";i:768;s:6:"height";i:509;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"large-thermos-1024x678.jpg";s:5:"width";i:1024;s:6:"height";i:678;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(352, 97, '_wp_attached_file', '2016/11/film-cameras.jpg'),
(353, 97, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1950;s:4:"file";s:24:"2016/11/film-cameras.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"film-cameras-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"film-cameras-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"film-cameras-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"film-cameras-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(354, 98, '_wp_attached_file', '2016/11/flannel-shirt.jpg'),
(355, 98, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1722;s:4:"file";s:25:"2016/11/flannel-shirt.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"flannel-shirt-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"flannel-shirt-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"flannel-shirt-768x509.jpg";s:5:"width";i:768;s:6:"height";i:509;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"flannel-shirt-1024x678.jpg";s:5:"width";i:1024;s:6:"height";i:678;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(356, 99, '_wp_attached_file', '2016/11/gas-stove.jpg'),
(357, 99, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1722;s:4:"file";s:21:"2016/11/gas-stove.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"gas-stove-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"gas-stove-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"gas-stove-768x509.jpg";s:5:"width";i:768;s:6:"height";i:509;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"gas-stove-1024x678.jpg";s:5:"width";i:1024;s:6:"height";i:678;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(358, 100, '_wp_attached_file', '2016/11/beach-tent-1.jpg'),
(359, 100, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1950;s:4:"file";s:24:"2016/11/beach-tent-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"beach-tent-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"beach-tent-1-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"beach-tent-1-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"beach-tent-1-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(360, 101, '_wp_attached_file', '2016/11/camper-van-1.jpg'),
(361, 101, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1125;s:4:"file";s:24:"2016/11/camper-van-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"camper-van-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"camper-van-1-300x169.jpg";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"camper-van-1-768x432.jpg";s:5:"width";i:768;s:6:"height";i:432;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"camper-van-1-1024x576.jpg";s:5:"width";i:1024;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(362, 102, '_wp_attached_file', '2016/11/ceramic-mugs.jpg'),
(363, 102, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:24:"2016/11/ceramic-mugs.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"ceramic-mugs-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"ceramic-mugs-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"ceramic-mugs-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"ceramic-mugs-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(364, 86, 'product_price', '$220.00'),
(365, 86, '_thumbnail_id', '90'),
(366, 103, '_edit_last', '1'),
(367, 103, '_edit_lock', '1479986979:1'),
(368, 103, 'product_price', '$75.00'),
(369, 103, '_thumbnail_id', '93'),
(370, 104, '_edit_last', '1'),
(371, 104, '_edit_lock', '1479986963:1'),
(372, 104, 'product_price', '$150.00'),
(373, 104, '_thumbnail_id', '97'),
(374, 105, '_edit_last', '1'),
(375, 105, '_edit_lock', '1479986945:1'),
(376, 105, 'product_price', '$100.00'),
(377, 105, '_thumbnail_id', '91'),
(378, 106, '_edit_last', '1'),
(379, 106, '_edit_lock', '1479985184:1'),
(380, 106, 'product_price', '$400.00'),
(381, 106, '_thumbnail_id', '87'),
(382, 107, '_edit_last', '1'),
(383, 107, '_edit_lock', '1479985166:1'),
(384, 107, 'product_price', '$40.00'),
(385, 107, '_thumbnail_id', '88'),
(386, 108, '_edit_last', '1'),
(387, 108, '_edit_lock', '1479985153:1'),
(388, 108, 'product_price', '$19.00'),
(389, 108, '_thumbnail_id', '102'),
(390, 109, '_edit_last', '1'),
(391, 109, '_edit_lock', '1479985137:1'),
(392, 109, 'product_price', '$120.00'),
(393, 109, '_thumbnail_id', '99'),
(394, 110, '_edit_last', '1'),
(395, 110, '_edit_lock', '1479985123:1'),
(396, 110, 'product_price', '$42.00'),
(397, 110, '_thumbnail_id', '96'),
(399, 112, '_edit_last', '1'),
(400, 112, '_edit_lock', '1479985103:1'),
(401, 112, 'product_price', '$22.00'),
(402, 112, '_thumbnail_id', '92'),
(403, 113, '_edit_last', '1'),
(404, 113, '_edit_lock', '1479985089:1'),
(405, 113, 'product_price', '$45.00'),
(406, 113, '_thumbnail_id', '98'),
(407, 114, '_edit_last', '1'),
(408, 114, '_edit_lock', '1479985072:1'),
(409, 114, 'product_price', '$28.00'),
(410, 114, '_thumbnail_id', '94'),
(411, 115, 'product_price', '$135.00'),
(412, 115, '_edit_last', '1'),
(413, 115, '_thumbnail_id', '95'),
(414, 115, '_edit_lock', '1479985052:1'),
(415, 116, '_edit_last', '1'),
(416, 116, '_edit_lock', '1480000928:1'),
(417, 116, 'product_price', '$60.00'),
(418, 116, '_thumbnail_id', '89'),
(419, 81, 'product_price', '$155.00'),
(420, 81, '_thumbnail_id', '100'),
(421, 118, '_form', '<label> Your Name (required)\n    [text* your-name] </label>\n\n<label> Your Email (required)\n    [email* your-email] </label>\n\n<label> Subject\n    [text your-subject] </label>\n\n<label> Your Message\n    [textarea your-message] </label>\n\n[submit "Send"]'),
(422, 118, '_mail', 'a:8:{s:7:"subject";s:27:"inhabitent "[your-subject]"";s:6:"sender";s:36:"[your-name] <kiana.aghaei@gmail.com>";s:4:"body";s:172:"From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n--\nThis e-mail was sent from a contact form on inhabitent (http://localhost/student)";s:9:"recipient";s:22:"kiana.aghaei@gmail.com";s:18:"additional_headers";s:22:"Reply-To: [your-email]";s:11:"attachments";s:0:"";s:8:"use_html";i:0;s:13:"exclude_blank";i:0;}'),
(423, 118, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:27:"inhabitent "[your-subject]"";s:6:"sender";s:35:"inhabitent <kiana.aghaei@gmail.com>";s:4:"body";s:114:"Message Body:\n[your-message]\n\n--\nThis e-mail was sent from a contact form on inhabitent (http://localhost/student)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:32:"Reply-To: kiana.aghaei@gmail.com";s:11:"attachments";s:0:"";s:8:"use_html";i:0;s:13:"exclude_blank";i:0;}'),
(424, 118, '_messages', 'a:8:{s:12:"mail_sent_ok";s:45:"Thank you for your message. It has been sent.";s:12:"mail_sent_ng";s:71:"There was an error trying to send your message. Please try again later.";s:16:"validation_error";s:61:"One or more fields have an error. Please check and try again.";s:4:"spam";s:71:"There was an error trying to send your message. Please try again later.";s:12:"accept_terms";s:69:"You must accept the terms and conditions before sending your message.";s:16:"invalid_required";s:22:"The field is required.";s:16:"invalid_too_long";s:22:"The field is too long.";s:17:"invalid_too_short";s:23:"The field is too short.";}'),
(425, 118, '_additional_settings', NULL),
(426, 118, '_locale', 'en_US'),
(427, 23, '_wp_page_template', 'default'),
(433, 21, '_thumbnail_id', '60'),
(438, 21, 'our_story', 'Inhabitent Camping Supply Co. has been Vancouver baked-good icon for more than two whole months! Customers often comment on the bustle of activity they see in store…that’s where the magic happens every day.  We want to bridge the gap between the comfort of city life and the lovely Instagram-worthiness of the great outdoors that surround us. We sell gear that’s fun and functional. So much fun, in fact, that you’ll want to pitch a tent inside your one-bedroom apartment so you can use it everyday.'),
(439, 21, 'our_team', 'Inhabitent Camping Supply Co.’s staff is made up of an amazing team of inspired retail associates. We really know our stuff when it comes to travel hammocks and campfire cooking gadgets. From a provincial park campground to the back-country, our staff knows what you need to outfit your outdoor outing.  Our shop in nestled away in a lovely little corner of Vancouver. Pop in, say hi, and try out our tents!'),
(440, 59, '_wp_trash_meta_status', 'publish'),
(441, 59, '_wp_trash_meta_time', '1479947039') ;
INSERT INTO `igefiefpostmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(442, 59, '_wp_desired_post_slug', 'about-page-content'),
(443, 21, 'aboout_background_image', '60'),
(444, 21, 'our_story', '<p class="p1"><span class="s1">Inhabitent Camping Supply Co. has been Vancouver baked-good icon for more than two whole months! Customers often comment on the bustle of activity they see in store…that’s where the magic happens every day.</span></p><p class="p1"><span class="s1">We want to bridge the gap between the comfort of city life and the lovely Instagram-worthiness of the great outdoors that surround us. We sell gear that’s fun and functional. So much fun, in fact, that you’ll want to pitch a tent inside your one-bedroom apartment so you can use it everyday.</span></p>'),
(445, 21, 'our_team', '<p class="p1"><span class="s1">Inhabitent Camping Supply Co.’s staff is made up of an amazing team of inspired retail associates. We really know our stuff when it comes to travel hammocks and campfire cooking gadgets. From a provincial park campground to the back-country, our staff knows what you need to outfit your outdoor outing.</span></p><p class="p1"><span class="s1">Our shop in nestled away in a lovely little corner of Vancouver. Pop in, say hi, and try out our tents!</span></p>') ;

#
# End of data contents of table `igefiefpostmeta`
# --------------------------------------------------------



#
# Delete any existing table `igefiefposts`
#

DROP TABLE IF EXISTS `igefiefposts`;


#
# Table structure of table `igefiefposts`
#

CREATE TABLE `igefiefposts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `igefiefposts`
#
INSERT INTO `igefiefposts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2016-11-07 09:23:56', '2016-11-07 09:23:56', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2016-11-09 02:45:54', '2016-11-09 02:45:54', '', 0, 'http://localhost/student/?p=1', 0, 'post', '', 1),
(2, 1, '2016-11-07 09:23:56', '2016-11-07 09:23:56', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http:/localhost:8888/inhabitent/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2016-11-07 22:37:06', '2016-11-07 22:37:06', '', 0, 'http://localhost/student/?page_id=2', 0, 'page', '', 0),
(8, 1, '2016-11-07 22:06:28', '2016-11-07 22:06:28', '', 'Price', '', 'publish', 'closed', 'closed', '', 'price', '', '', '2016-11-07 22:06:28', '2016-11-07 22:06:28', '', 0, 'http://localhost/student/?post_type=cfs&#038;p=8', 0, 'cfs', '', 0),
(10, 1, '2016-11-07 22:12:55', '2016-11-07 22:12:55', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Camper Van', '', 'publish', 'closed', 'closed', '', 'camper-van', '', '', '2016-11-24 11:30:22', '2016-11-24 11:30:22', '', 0, 'http://localhost/student/?post_type=product&#038;p=10', 0, 'product', '', 0),
(12, 1, '2016-11-07 22:24:05', '2016-11-07 22:24:05', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2016-11-07 22:24:05', '2016-11-07 22:24:05', '', 0, 'http://localhost/student/?page_id=12', 0, 'page', '', 0),
(13, 1, '2016-11-07 22:24:05', '2016-11-07 22:24:05', '', 'Home', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2016-11-07 22:24:05', '2016-11-07 22:24:05', '', 12, 'http://localhost/student/2016/11/07/12-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2016-11-07 22:35:28', '2016-11-07 22:35:28', '', 'journal', '', 'publish', 'closed', 'closed', '', 'journal', '', '', '2016-11-07 22:35:28', '2016-11-07 22:35:28', '', 0, 'http://localhost/student/?page_id=16', 0, 'page', '', 0),
(17, 1, '2016-11-07 22:35:28', '2016-11-07 22:35:28', '', 'journal', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2016-11-07 22:35:28', '2016-11-07 22:35:28', '', 16, 'http://localhost/student/2016/11/07/16-revision-v1/', 0, 'revision', '', 0),
(18, 1, '2016-11-07 22:37:06', '2016-11-07 22:37:06', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http:/localhost:8888/inhabitent/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2016-11-07 22:37:06', '2016-11-07 22:37:06', '', 2, 'http://localhost/student/2016/11/07/2-revision-v1/', 0, 'revision', '', 0),
(21, 1, '2016-11-07 22:42:02', '2016-11-07 22:42:02', '', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2016-11-24 00:26:32', '2016-11-24 00:26:32', '', 0, 'http://localhost/student/?page_id=21', 0, 'page', '', 0),
(22, 1, '2016-11-07 22:42:02', '2016-11-07 22:42:02', '', 'about', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2016-11-07 22:42:02', '2016-11-07 22:42:02', '', 21, 'http://localhost/student/2016/11/07/21-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2016-11-07 22:42:14', '2016-11-07 22:42:14', '<iframe style="border: 0;" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d10414.774646267038!2d-123.13632300000002!3d49.263252!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x548673c79e1ac457%3A0x3aea6428fa30dc6a!2s1490+W+Broadway%2C+Vancouver%2C+BC+V6H%2C+Canada!5e0!3m2!1sen!2sca!4v1478663734077" width="760" height="300" frameborder="0" allowfullscreen="allowfullscreen"></iframe>\r\n\r\n&nbsp;\r\n<h2>WE TAKE CAMPING VERY SERIOUSLY.</h2>\r\nInhabitent Camping Supply Co. knows what it takes to outfit a camping trip right. From flannel shirts to artisanal axes, we’ve got your covered. Please contact us below with any questions comments or suggestions.\r\n<h2>SEND US EMAIL!</h2>\r\n&nbsp;\r\n\r\n[contact-form-7 id="118" title="Contact form 1"]', 'Find Us', '', 'publish', 'closed', 'closed', '', 'find-us', '', '', '2016-11-09 21:26:39', '2016-11-09 21:26:39', '', 0, 'http://localhost/student/?page_id=23', 0, 'page', '', 0),
(24, 1, '2016-11-07 22:42:14', '2016-11-07 22:42:14', '', 'find us', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2016-11-07 22:42:14', '2016-11-07 22:42:14', '', 23, 'http://localhost/student/2016/11/07/23-revision-v1/', 0, 'revision', '', 0),
(25, 1, '2016-11-08 00:31:42', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-11-08 00:31:42', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=25', 1, 'nav_menu_item', '', 0),
(26, 1, '2016-11-08 00:31:42', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-11-08 00:31:42', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=26', 1, 'nav_menu_item', '', 0),
(27, 1, '2016-11-08 00:31:42', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-11-08 00:31:42', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=27', 1, 'nav_menu_item', '', 0),
(28, 1, '2016-11-08 00:31:42', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-11-08 00:31:42', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=28', 1, 'nav_menu_item', '', 0),
(29, 1, '2016-11-08 00:31:42', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-11-08 00:31:42', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=29', 1, 'nav_menu_item', '', 0),
(30, 1, '2016-11-08 00:34:19', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-11-08 00:34:19', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=30', 1, 'nav_menu_item', '', 0),
(31, 1, '2016-11-08 00:34:20', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-11-08 00:34:20', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=31', 1, 'nav_menu_item', '', 0),
(32, 1, '2016-11-08 00:34:20', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-11-08 00:34:20', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=32', 1, 'nav_menu_item', '', 0),
(33, 1, '2016-11-08 00:34:20', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-11-08 00:34:20', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=33', 1, 'nav_menu_item', '', 0),
(34, 1, '2016-11-08 00:34:20', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-11-08 00:34:20', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=34', 1, 'nav_menu_item', '', 0),
(35, 1, '2016-11-08 00:35:51', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-11-08 00:35:51', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=35', 1, 'nav_menu_item', '', 0),
(36, 1, '2016-11-08 00:35:52', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-11-08 00:35:52', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=36', 1, 'nav_menu_item', '', 0),
(37, 1, '2016-11-08 00:35:52', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-11-08 00:35:52', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=37', 1, 'nav_menu_item', '', 0),
(38, 1, '2016-11-08 00:35:52', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-11-08 00:35:52', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=38', 1, 'nav_menu_item', '', 0),
(39, 1, '2016-11-08 00:35:52', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-11-08 00:35:52', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=39', 1, 'nav_menu_item', '', 0),
(40, 1, '2016-11-08 01:32:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-11-08 01:32:33', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=40', 1, 'nav_menu_item', '', 0),
(41, 1, '2016-11-08 01:32:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-11-08 01:32:33', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=41', 1, 'nav_menu_item', '', 0),
(42, 1, '2016-11-08 01:32:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-11-08 01:32:33', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=42', 1, 'nav_menu_item', '', 0),
(43, 1, '2016-11-08 01:32:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-11-08 01:32:33', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=43', 1, 'nav_menu_item', '', 0),
(44, 1, '2016-11-08 01:32:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-11-08 01:32:33', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=44', 1, 'nav_menu_item', '', 0),
(46, 1, '2016-11-08 01:39:06', '2016-11-08 01:39:06', ' ', '', '', 'publish', 'closed', 'closed', '', '46', '', '', '2016-11-09 02:56:01', '2016-11-09 02:56:01', '', 0, 'http://localhost/student/?p=46', 3, 'nav_menu_item', '', 0),
(47, 1, '2016-11-08 01:39:06', '2016-11-08 01:39:06', ' ', '', '', 'publish', 'closed', 'closed', '', '47', '', '', '2016-11-09 02:56:01', '2016-11-09 02:56:01', '', 0, 'http://localhost/student/?p=47', 4, 'nav_menu_item', '', 0),
(48, 1, '2016-11-08 01:33:50', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-11-08 01:33:50', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=48', 1, 'nav_menu_item', '', 0),
(49, 1, '2016-11-08 01:39:06', '2016-11-08 01:39:06', ' ', '', '', 'publish', 'closed', 'closed', '', '49', '', '', '2016-11-09 02:56:01', '2016-11-09 02:56:01', '', 0, 'http://localhost/student/?p=49', 2, 'nav_menu_item', '', 0),
(50, 1, '2016-11-10 18:21:43', '2016-11-10 18:21:43', 'Ethical tumblr gentrify listicle roof party. Normcore jean shorts single-origin coffee aesthetic, selvage williamsburg chartreuse austin banjo tumblr trust fund. Vinyl freegan trust fund, blue bottle chicharrones VHS fanny pack pop-up tumblr put a bird on it blog whatever. Authentic next level shabby chic squid. Brooklyn chicharrones fanny pack waistcoat deep v. Distillery cronut man bun, readymade gluten-free fap listicle bespoke meh cray yuccie vinyl sartorial kogi. Pickled retro organic kale chips.\r\n\r\nShabby chic bicycle rights vinyl, ugh ennui wayfarers four dollar toast. Leggings beard ennui, bushwick mixtape next level meditation master cleanse bicycle rights single-origin coffee post-ironic kogi butcher. Cold-pressed yuccie knausgaard truffaut, messenger bag blog plaid seitan pork belly chambray echo park. PBR&amp;B direct trade lomo actually quinoa. Marfa you probably haven’t heard of them fanny pack, everyday carry craft beer ethical before they sold out bespoke pabst truffaut chicharrones pitchfork synth echo park biodiesel. Kinfolk disrupt four loko plaid, tumblr cold-pressed YOLO microdosing art party stumptown hammock. Fap man braid polaroid pug.', 'Van Camping Photo Contest', '', 'publish', 'open', 'open', '', 'van-camping-photo-contest', '', '', '2016-11-24 10:54:38', '2016-11-24 10:54:38', '', 0, 'http://localhost/student/?p=50', 0, 'post', '', 0),
(51, 1, '2016-11-08 18:17:37', '2016-11-08 18:17:37', '', 'van-camper', '', 'inherit', 'open', 'closed', '', 'van-camper', '', '', '2016-11-08 18:17:37', '2016-11-08 18:17:37', '', 50, 'http://localhost/student/wp-content/uploads/2016/11/van-camper-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(52, 1, '2016-11-08 18:18:17', '2016-11-08 18:18:17', '&nbsp;\r\n\r\n&nbsp;\r\n\r\nEthical tumblr gentrify listicle roof party. Normcore jean shorts single-origin coffee aesthetic, selvage williamsburg chartreuse austin banjo tumblr trust fund. Vinyl freegan trust fund, blue bottle chicharrones VHS fanny pack pop-up tumblr put a bird on it blog whatever. Authentic next level shabby chic squid. Brooklyn chicharrones fanny pack waistcoat deep v. Distillery cronut man bun, readymade gluten-free fap listicle bespoke meh cray yuccie vinyl sartorial kogi. Pickled retro organic kale chips.\r\n\r\nShabby chic bicycle rights vinyl, ugh ennui wayfarers four dollar toast. Leggings beard ennui, bushwick mixtape next level meditation master cleanse bicycle rights single-origin coffee post-ironic kogi butcher. Cold-pressed yuccie knausgaard truffaut, messenger bag blog plaid seitan pork belly chambray echo park. PBR&amp;B direct trade lomo actually quinoa. Marfa you probably haven’t heard of them fanny pack, everyday carry craft beer ethical before they sold out bespoke pabst truffaut chicharrones pitchfork synth echo park biodiesel. Kinfolk disrupt four loko plaid, tumblr cold-pressed YOLO microdosing art party stumptown hammock. Fap man braid polaroid pug.', 'VAN CAMPING PHOTO CONTEST', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2016-11-08 18:18:17', '2016-11-08 18:18:17', '', 50, 'http://localhost/student/2016/11/08/50-revision-v1/', 0, 'revision', '', 0),
(53, 1, '2016-11-08 18:19:58', '2016-11-08 18:19:58', '&nbsp;\r\n\r\n&nbsp;\r\n\r\n&nbsp;\r\n\r\n<img class="alignnone  wp-image-51" src="http:/localhost:8888/inhabitent/wp-content/uploads/2016/11/van-camper-1-300x205.jpg" alt="van-camper" width="721" height="493" />\r\n\r\nEthical tumblr gentrify listicle roof party. Normcore jean shorts single-origin coffee aesthetic, selvage williamsburg chartreuse austin banjo tumblr trust fund. Vinyl freegan trust fund, blue bottle chicharrones VHS fanny pack pop-up tumblr put a bird on it blog whatever. Authentic next level shabby chic squid. Brooklyn chicharrones fanny pack waistcoat deep v. Distillery cronut man bun, readymade gluten-free fap listicle bespoke meh cray yuccie vinyl sartorial kogi. Pickled retro organic kale chips.\r\n\r\nShabby chic bicycle rights vinyl, ugh ennui wayfarers four dollar toast. Leggings beard ennui, bushwick mixtape next level meditation master cleanse bicycle rights single-origin coffee post-ironic kogi butcher. Cold-pressed yuccie knausgaard truffaut, messenger bag blog plaid seitan pork belly chambray echo park. PBR&amp;B direct trade lomo actually quinoa. Marfa you probably haven’t heard of them fanny pack, everyday carry craft beer ethical before they sold out bespoke pabst truffaut chicharrones pitchfork synth echo park biodiesel. Kinfolk disrupt four loko plaid, tumblr cold-pressed YOLO microdosing art party stumptown hammock. Fap man braid polaroid pug.', 'VAN CAMPING PHOTO CONTEST', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2016-11-08 18:19:58', '2016-11-08 18:19:58', '', 50, 'http://localhost/student/2016/11/08/50-revision-v1/', 0, 'revision', '', 0),
(54, 1, '2016-11-08 18:21:05', '2016-11-08 18:21:05', 'Ethical tumblr gentrify listicle roof party. Normcore jean shorts single-origin coffee aesthetic, selvage williamsburg chartreuse austin banjo tumblr trust fund. Vinyl freegan trust fund, blue bottle chicharrones VHS fanny pack pop-up tumblr put a bird on it blog whatever. Authentic next level shabby chic squid. Brooklyn chicharrones fanny pack waistcoat deep v. Distillery cronut man bun, readymade gluten-free fap listicle bespoke meh cray yuccie vinyl sartorial kogi. Pickled retro organic kale chips.\r\n\r\nShabby chic bicycle rights vinyl, ugh ennui wayfarers four dollar toast. Leggings beard ennui, bushwick mixtape next level meditation master cleanse bicycle rights single-origin coffee post-ironic kogi butcher. Cold-pressed yuccie knausgaard truffaut, messenger bag blog plaid seitan pork belly chambray echo park. PBR&amp;B direct trade lomo actually quinoa. Marfa you probably haven’t heard of them fanny pack, everyday carry craft beer ethical before they sold out bespoke pabst truffaut chicharrones pitchfork synth echo park biodiesel. Kinfolk disrupt four loko plaid, tumblr cold-pressed YOLO microdosing art party stumptown hammock. Fap man braid polaroid pug.', 'VAN CAMPING PHOTO CONTEST', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2016-11-08 18:21:05', '2016-11-08 18:21:05', '', 50, 'http://localhost/student/2016/11/08/50-revision-v1/', 0, 'revision', '', 0),
(55, 1, '2016-11-10 18:27:54', '2016-11-10 18:27:54', 'Try-hard listicle truffaut locavore, pabst humblebrag bespoke flexitarian squid street art chia chicharrones. Gastropub portland cornhole poutine 90’s drinking vinegar, semiotics raw denim. Helvetica cornhole health goth pickled, portland banjo knausgaard drinking vinegar DIY YOLO trust fund tumblr skateboard church-key slow-carb. Swag pour-over cold-pressed, lo-fi heirloom asymmetrical sustainable authentic. Irony helvetica forage, mlkshk single-origin coffee scenester banjo jean shorts echo park hoodie ennui raw denim bitters tattooed plaid. Paleo quinoa mustache echo park, shoreditch scenester bitters chia shabby chic man braid tofu. Portland man bun scenester, wolf master cleanse iPhone selfies readymade godard sustainable asymmetrical williamsburg.\r\n\r\nHealth goth ramps cold-pressed, literally etsy lomo fashion axe brunch dreamcatcher mlkshk vegan. Dreamcatcher squid shoreditch, kogi cold-pressed paleo four loko DIY umami keffiyeh. Blog green juice tofu yr chillwave taxidermy. Kinfolk aesthetic asymmetrical, waistcoat cray fashion axe keytar pork belly truffaut narwhal post-ironic squid listicle poutine. Twee quinoa brooklyn pour-over, beard wayfarers flannel. Shoreditch meditation ramps, tofu keytar etsy plaid bespoke. Yr synth poutine, farm-to-table raw denim mixtape everyday carry brunch scenester.', 'Fireside Libations: 3 Warm Coctaile Recipes', '', 'publish', 'open', 'open', '', 'fireside-libations-3-warm-cocktail-recipes', '', '', '2016-11-24 10:54:02', '2016-11-24 10:54:02', '', 0, 'http://localhost/student/?p=55', 0, 'post', '', 0),
(56, 1, '2016-11-08 18:25:09', '2016-11-08 18:25:09', '', 'warm-cocktail', '', 'inherit', 'open', 'closed', '', 'warm-cocktail', '', '', '2016-11-08 18:25:09', '2016-11-08 18:25:09', '', 55, 'http://localhost/student/wp-content/uploads/2016/11/warm-cocktail-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(57, 1, '2016-11-08 18:27:03', '2016-11-08 18:27:03', 'Try-hard listicle truffaut locavore, pabst humblebrag bespoke flexitarian squid street art chia chicharrones. Gastropub portland cornhole poutine 90’s drinking vinegar, semiotics raw denim. Helvetica cornhole health goth pickled, portland banjo knausgaard drinking vinegar DIY YOLO trust fund tumblr skateboard church-key slow-carb. Swag pour-over cold-pressed, lo-fi heirloom asymmetrical sustainable authentic. Irony helvetica forage, mlkshk single-origin coffee scenester banjo jean shorts echo park hoodie ennui raw denim bitters tattooed plaid. Paleo quinoa mustache echo park, shoreditch scenester bitters chia shabby chic man braid tofu. Portland man bun scenester, wolf master cleanse iPhone selfies readymade godard sustainable asymmetrical williamsburg.\r\n\r\nHealth goth ramps cold-pressed, literally etsy lomo fashion axe brunch dreamcatcher mlkshk vegan. Dreamcatcher squid shoreditch, kogi cold-pressed paleo four loko DIY umami keffiyeh. Blog green juice tofu yr chillwave taxidermy. Kinfolk aesthetic asymmetrical, waistcoat cray fashion axe keytar pork belly truffaut narwhal post-ironic squid listicle poutine. Twee quinoa brooklyn pour-over, beard wayfarers flannel. Shoreditch meditation ramps, tofu keytar etsy plaid bespoke. Yr synth poutine, farm-to-table raw denim mixtape everyday carry brunch scenester.', 'FIRESIDE LIBATIONS: 3 WARM COCKTAIL RECIPES', '', 'inherit', 'closed', 'closed', '', '55-revision-v1', '', '', '2016-11-08 18:27:03', '2016-11-08 18:27:03', '', 55, 'http://localhost/student/2016/11/08/55-revision-v1/', 0, 'revision', '', 0),
(58, 1, '2016-11-08 21:55:39', '2016-11-08 21:55:39', '', 'About Page Background Image', '', 'publish', 'closed', 'closed', '', 'about-page-background-image', '', '', '2016-11-24 00:25:24', '2016-11-24 00:25:24', '', 0, 'http://localhost/student/?post_type=cfs&#038;p=58', 0, 'cfs', '', 0),
(59, 1, '2016-11-08 23:04:03', '2016-11-08 23:04:03', '', 'About page content', '', 'trash', 'closed', 'closed', '', 'about-page-content__trashed', '', '', '2016-11-24 00:23:59', '2016-11-24 00:23:59', '', 0, 'http://localhost/student/?post_type=cfs&#038;p=59', 0, 'cfs', '', 0),
(60, 1, '2016-11-08 22:57:57', '2016-11-08 22:57:57', '', 'about-hero', '', 'inherit', 'open', 'closed', '', 'about-hero', '', '', '2016-11-08 22:57:57', '2016-11-08 22:57:57', '', 21, 'http://localhost/student/wp-content/uploads/2016/11/about-hero.jpg', 0, 'attachment', 'image/jpeg', 0),
(62, 1, '2016-11-08 22:59:33', '2016-11-08 22:59:33', '', 'About', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2016-11-08 22:59:33', '2016-11-08 22:59:33', '', 21, 'http://localhost/student/2016/11/08/21-revision-v1/', 0, 'revision', '', 0),
(64, 1, '2016-11-09 00:34:32', '2016-11-09 00:34:32', '', 'about-hero', '', 'inherit', 'open', 'closed', '', 'about-hero-2', '', '', '2016-11-09 00:34:32', '2016-11-09 00:34:32', '', 50, 'http://localhost/student/wp-content/uploads/2016/11/about-hero.jpg', 0, 'attachment', 'image/jpeg', 0),
(66, 1, '2016-11-10 00:39:24', '2016-11-10 00:39:24', 'Gochujang cronut authentic, cliche chicharrones food truck aesthetic whatever iPhone tousled. Paleo semiotics gastropub messenger bag, kogi beard tattooed truffaut cred artisan. Skateboard cliche selfies fashion axe, viral ugh vinyl plaid before they sold out squid jean shorts tofu letterpress. Kombucha gluten-free banh mi authentic paleo, kale chips typewriter kogi normcore mustache cliche before they sold out intelligentsia poutine 90’s. Fixie mlkshk put a bird on it messenger bag cardigan, gochujang cronut health goth tousled truffaut humblebrag keytar you probably haven’t heard of them chillwave. Put a bird on it flexitarian cornhole leggings umami. Umami polaroid gentrify distillery tacos flannel green juice.\r\n\r\nTruffaut twee master cleanse, drinking vinegar poutine +1 letterpress fanny pack. Truffaut dreamcatcher church-key 90’s bicycle rights. Actually tumblr fingerstache schlitz trust fund keffiyeh. Gastropub pitchfork jean shorts paleo, photo booth 90’s yr drinking vinegar shore ditch vice iPhone 3 wolf moon neutra craft beer taxidermy. Cronut YOLO readymade man bun, trust fund kale chips leggings four loko chia blue bottle raw denim wayfarers beard. Authentic freegan waistcoat hoodie. Hashtag dreamcatcher pickled, locavore messenger bag banh mi tousled man braid ennui.', 'How to: Eating Healthy Meals in the Wild', '', 'publish', 'open', 'open', '', 'how-to-eating-healthy-meals-in-the-wild', '', '', '2016-11-24 10:55:35', '2016-11-24 10:55:35', '', 0, 'http://localhost/student/?p=66', 0, 'post', '', 0),
(67, 1, '2016-11-09 00:39:13', '2016-11-09 00:39:13', '', 'healthy-camp-food', '', 'inherit', 'open', 'closed', '', 'healthy-camp-food', '', '', '2016-11-09 00:39:13', '2016-11-09 00:39:13', '', 66, 'http://localhost/student/wp-content/uploads/2016/11/healthy-camp-food-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(68, 1, '2016-11-09 00:39:24', '2016-11-09 00:39:24', 'Gochujang cronut authentic, cliche chicharrones food truck aesthetic whatever iPhone tousled. Paleo semiotics gastropub messenger bag, kogi beard tattooed truffaut cred artisan. Skateboard cliche selfies fashion axe, viral ugh vinyl plaid before they sold out squid jean shorts tofu letterpress. Kombucha gluten-free banh mi authentic paleo, kale chips typewriter kogi normcore mustache cliche before they sold out intelligentsia poutine 90’s. Fixie mlkshk put a bird on it messenger bag cardigan, gochujang cronut health goth tousled truffaut humblebrag keytar you probably haven’t heard of them chillwave. Put a bird on it flexitarian cornhole leggings umami. Umami polaroid gentrify distillery tacos flannel green juice.\r\n\r\nTruffaut twee master cleanse, drinking vinegar poutine +1 letterpress fanny pack. Truffaut dreamcatcher church-key 90’s bicycle rights. Actually tumblr fingerstache schlitz trust fund keffiyeh. Gastropub pitchfork jean shorts paleo, photo booth 90’s yr drinking vinegar shoreditch vice iPhone 3 wolf moon neutra craft beer taxidermy. Cronut YOLO readymade man bun, trust fund kale chips meggings four loko chia blue bottle raw denim wayfarers beard. Authentic freegan waistcoat hoodie. Hashtag dreamcatcher pickled, locavore messenger bag banh mi tousled man braid ennui.', 'HOW TO: EATING HEALTHY MEALS IN THE WILD', '', 'inherit', 'closed', 'closed', '', '66-revision-v1', '', '', '2016-11-09 00:39:24', '2016-11-09 00:39:24', '', 66, 'http://localhost/student/2016/11/09/66-revision-v1/', 0, 'revision', '', 0),
(70, 1, '2016-11-09 00:43:00', '2016-11-09 00:43:00', 'Wayfarers VHS chambray schlitz, ramps semiotics post-ironic franzen fixie wolf polaroid viral. Blue bottle scenester paleo bitters, master cleanse put a bird on it PBR&amp;B brunch kinfolk echo park pitchfork YOLO. Forage biodiesel polaroid beard, scenester normcore actually swag food truck meggings. Readymade cornhole pabst gastropub. Roof party put a bird on it quinoa, bicycle rights kickstarter venmo master cleanse. Sustainable keffiyeh leggings, farm-to-table cliche banh mi drinking vinegar. Crucifix tote bag pork belly, before they sold out artisan YOLO listicle kombucha gluten-free vice shoreditch actually swag direct trade.\r\n\r\nVenmo XOXO meh hella raw denim. Migas listicle photo booth, wayfarers single-origin coffee artisan gastropub iPhone echo park. Banjo forage kale chips tilde semiotics echo park artisan art party, meditation viral retro pitchfork. Seitan tacos cray waistcoat, migas pickled fap try-hard gentrify narwhal pinterest thundercats keffiyeh. Keffiyeh hashtag tofu slow-carb, yr pork belly VHS normcore typewriter gastropub letterpress echo park. Ugh sriracha messenger bag umami, mixtape vice flexitarian forage iPhone synth sustainable banjo. Banh mi humblebrag shoreditch, single-origin coffee butcher skateboard farm-to-table bicycle rights.', '5 Tips For Solo Camping', '', 'publish', 'open', 'open', '', '5-tips-for-solo-camping', '', '', '2016-11-24 10:56:26', '2016-11-24 10:56:26', '', 0, 'http://localhost/student/?p=70', 0, 'post', '', 0),
(71, 1, '2016-11-09 00:42:48', '2016-11-09 00:42:48', '', 'solo-camping', '', 'inherit', 'open', 'closed', '', 'solo-camping', '', '', '2016-11-09 00:42:48', '2016-11-09 00:42:48', '', 70, 'http://localhost/student/wp-content/uploads/2016/11/solo-camping-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(72, 1, '2016-11-09 00:43:00', '2016-11-09 00:43:00', 'Wayfarers VHS chambray schlitz, ramps semiotics post-ironic franzen fixie wolf polaroid viral. Blue bottle scenester paleo bitters, master cleanse put a bird on it PBR&amp;B brunch kinfolk echo park pitchfork YOLO. Forage biodiesel polaroid beard, scenester normcore actually swag food truck meggings. Readymade cornhole pabst gastropub. Roof party put a bird on it quinoa, bicycle rights kickstarter venmo master cleanse. Sustainable keffiyeh leggings, farm-to-table cliche banh mi drinking vinegar. Crucifix tote bag pork belly, before they sold out artisan YOLO listicle kombucha gluten-free vice shoreditch actually swag direct trade.\r\n\r\nVenmo XOXO meh hella raw denim. Migas listicle photo booth, wayfarers single-origin coffee artisan gastropub iPhone echo park. Banjo forage kale chips tilde semiotics echo park artisan art party, meditation viral retro pitchfork. Seitan tacos cray waistcoat, migas pickled fap try-hard gentrify narwhal pinterest thundercats keffiyeh. Keffiyeh hashtag tofu slow-carb, yr pork belly VHS normcore typewriter gastropub letterpress echo park. Ugh sriracha messenger bag umami, mixtape vice flexitarian forage iPhone synth sustainable banjo. Banh mi humblebrag shoreditch, single-origin coffee butcher skateboard farm-to-table bicycle rights.', '5 TIPS FOR SOLO CAMPING', '', 'inherit', 'closed', 'closed', '', '70-revision-v1', '', '', '2016-11-09 00:43:00', '2016-11-09 00:43:00', '', 70, 'http://localhost/student/2016/11/09/70-revision-v1/', 0, 'revision', '', 0),
(73, 1, '2016-11-09 02:21:09', '2016-11-09 02:21:09', 'Fashion axe schlitz selvage, art party fixie ugh skateboard fap keffiyeh intelligentsia gastropub tattooed humblebrag brunch shabby chic. Tilde selvage ennui, ethical sartorial keytar gastropub mlkshk. Migas seitan lumbersexual, paleo kogi sriracha photo booth hoodie franzen. XOXO fap master cleanse everyday carry, four loko helvetica marfa. Tousled health goth normcore, raw denim banh mi bespoke quinoa. Readymade keytar iPhone fashion axe, raw denim put a bird on it 3 wolf moon plaid fap you probably haven’t heard of them gentrify tumblr kickstarter seitan. Stumptown cold-pressed green juice, vinyl roof party mixtape gluten-free fashion axe kickstarter kitsch.\r\n\r\nKogi mixtape tousled chicharrones art party kinfolk. Synth vinyl tote bag food truck mumblecore roof party, fashion axe heirloom wolf twee butcher marfa gentrify keytar neutra. Scenester cardigan twee, gochujang butcher ugh blog before they sold out chambray sriracha cold-pressed fanny pack kitsch jean shorts. Master cleanse man bun flannel, locavore lo-fi hashtag next level wolf thundercats cronut man braid helvetica jean shorts listicle. XOXO kogi health goth, jean shorts scenester pug waistcoat shabby chic fap polaroid church-key organic brunch flexitarian. Yuccie lo-fi hammock VHS, waistcoat hashtag post-ironic gochujang helvetica paleo four loko kogi meh cray sartorial. Flexitarian paleo health goth freegan blue bottle.\r\n\r\nViral hashtag deep v, iPhone street art tacos helvetica semiotics sustainable man braid paleo affogato raw denim flexitarian mumblecore. Bicycle rights shabby chic humblebrag small batch pop-up. Slow-carb bespoke biodiesel sartorial migas fashion axe, mumblecore pop-up tumblr. Gentrify YOLO cray art party occupy, readymade wolf mustache. Food truck tacos microdosing poutine, kombucha YOLO mumblecore. Freegan typewriter distillery truffaut. Portland slow-carb hammock, yuccie cardigan before they sold out organic blog messenger bag tattooed church-key biodiesel XOXO tumblr.', 'Glamping Made Easy', '', 'publish', 'open', 'open', '', 'glamping-made-easy', '', '', '2016-11-24 10:56:00', '2016-11-24 10:56:00', '', 0, 'http://localhost/student/?p=73', 0, 'post', '', 0),
(74, 1, '2016-11-09 02:21:09', '2016-11-09 02:21:09', 'Fashion axe schlitz selvage, art party fixie ugh skateboard fap keffiyeh intelligentsia gastropub tattooed humblebrag brunch shabby chic. Tilde selvage ennui, ethical sartorial keytar gastropub mlkshk. Migas seitan lumbersexual, paleo kogi sriracha photo booth hoodie franzen. XOXO fap master cleanse everyday carry, four loko helvetica marfa. Tousled health goth normcore, raw denim banh mi bespoke quinoa. Readymade keytar iPhone fashion axe, raw denim put a bird on it 3 wolf moon plaid fap you probably haven’t heard of them gentrify tumblr kickstarter seitan. Stumptown cold-pressed green juice, vinyl roof party mixtape gluten-free fashion axe kickstarter kitsch.\r\n\r\nKogi mixtape tousled chicharrones art party kinfolk. Synth vinyl tote bag food truck mumblecore roof party, fashion axe heirloom wolf twee butcher marfa gentrify keytar neutra. Scenester cardigan twee, gochujang butcher ugh blog before they sold out chambray sriracha cold-pressed fanny pack kitsch jean shorts. Master cleanse man bun flannel, locavore lo-fi hashtag next level wolf thundercats cronut man braid helvetica jean shorts listicle. XOXO kogi health goth, jean shorts scenester pug waistcoat shabby chic fap polaroid church-key organic brunch flexitarian. Yuccie lo-fi hammock VHS, waistcoat hashtag post-ironic gochujang helvetica paleo four loko kogi meh cray sartorial. Flexitarian paleo health goth freegan blue bottle.\r\n\r\nViral hashtag deep v, iPhone street art tacos helvetica semiotics sustainable man braid paleo affogato raw denim flexitarian mumblecore. Bicycle rights shabby chic humblebrag small batch pop-up. Slow-carb bespoke biodiesel sartorial migas fashion axe, mumblecore pop-up tumblr. Gentrify YOLO cray art party occupy, readymade wolf mustache. Food truck tacos microdosing poutine, kombucha YOLO mumblecore. Freegan typewriter distillery truffaut. Portland slow-carb hammock, yuccie cardigan before they sold out organic blog messenger bag tattooed church-key biodiesel XOXO tumblr.', 'GLAMPING MADE EASY', '', 'inherit', 'closed', 'closed', '', '73-revision-v1', '', '', '2016-11-09 02:21:09', '2016-11-09 02:21:09', '', 73, 'http://localhost/student/2016/11/09/73-revision-v1/', 0, 'revision', '', 0),
(75, 1, '2016-11-09 02:42:01', '2016-11-09 02:42:01', '', 'GLAMPING MADE EASY', '', 'trash', 'open', 'open', '', '__trashed', '', '', '2016-11-09 02:44:07', '2016-11-09 02:44:07', '', 0, 'http://localhost/student/?p=75', 0, 'post', '', 0),
(76, 1, '2016-11-09 02:43:11', '2016-11-09 02:43:11', '', 'glamping', '', 'inherit', 'open', 'closed', '', 'glamping', '', '', '2016-11-09 02:43:11', '2016-11-09 02:43:11', '', 73, 'http://localhost/student/wp-content/uploads/2016/11/glamping-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(77, 1, '2016-11-09 02:44:07', '2016-11-09 02:44:07', '', 'GLAMPING MADE EASY', '', 'inherit', 'closed', 'closed', '', '75-revision-v1', '', '', '2016-11-09 02:44:07', '2016-11-09 02:44:07', '', 75, 'http://localhost/student/2016/11/09/75-revision-v1/', 0, 'revision', '', 0),
(79, 1, '2016-11-09 02:45:54', '2016-11-09 02:45:54', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2016-11-09 02:45:54', '2016-11-09 02:45:54', '', 1, 'http://localhost/student/2016/11/09/1-revision-v1/', 0, 'revision', '', 0),
(80, 1, '2016-11-09 02:56:01', '2016-11-09 02:56:01', 'products that inhabitent salls', 'Shop', '', 'publish', 'closed', 'closed', '', 'shop-2', '', '', '2016-11-09 02:56:01', '2016-11-09 02:56:01', '', 0, 'http://localhost/student/?p=80', 1, 'nav_menu_item', '', 0),
(81, 1, '2016-11-09 03:00:18', '2016-11-09 03:00:18', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Beach Tent', '', 'publish', 'closed', 'closed', '', 'beach-tent', '', '', '2016-11-24 11:30:10', '2016-11-24 11:30:10', '', 0, 'http://localhost/student/?post_type=product&#038;p=81', 0, 'product', '', 0),
(82, 1, '2016-11-09 03:05:40', '2016-11-09 03:05:40', '', 'beach-tent', '', 'inherit', 'open', 'closed', '', 'beach-tent-2', '', '', '2016-11-09 03:05:40', '2016-11-09 03:05:40', '', 81, 'http://localhost/student/wp-content/uploads/2016/11/beach-tent.jpg', 0, 'attachment', 'image/jpeg', 0),
(84, 1, '2016-11-09 03:08:12', '2016-11-09 03:08:12', '', 'camper-van', '', 'inherit', 'open', 'closed', '', 'camper-van-2', '', '', '2016-11-09 03:08:12', '2016-11-09 03:08:12', '', 10, 'http://localhost/student/wp-content/uploads/2016/11/camper-van.jpg', 0, 'attachment', 'image/jpeg', 0),
(85, 1, '2016-11-09 03:08:29', '2016-11-09 03:08:29', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'CAMPER VAN', '', 'inherit', 'closed', 'closed', '', '10-autosave-v1', '', '', '2016-11-09 03:08:29', '2016-11-09 03:08:29', '', 10, 'http://localhost/student/2016/11/09/10-autosave-v1/', 0, 'revision', '', 0),
(86, 1, '2016-11-09 03:11:29', '2016-11-09 03:11:29', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Nylon Tents', '', 'publish', 'closed', 'closed', '', 'nylon-tents', '', '', '2016-11-24 11:29:57', '2016-11-24 11:29:57', '', 0, 'http://localhost/student/?post_type=product&#038;p=86', 0, 'product', '', 0),
(87, 1, '2016-11-09 03:10:49', '2016-11-09 03:10:49', '', 'weathered-canoes', '', 'inherit', 'open', 'closed', '', 'weathered-canoes', '', '', '2016-11-09 03:10:49', '2016-11-09 03:10:49', '', 86, 'http://localhost/student/wp-content/uploads/2016/11/weathered-canoes.jpg', 0, 'attachment', 'image/jpeg', 0),
(88, 1, '2016-11-09 03:10:52', '2016-11-09 03:10:52', '', 'wood-ax', '', 'inherit', 'open', 'closed', '', 'wood-ax', '', '', '2016-11-09 03:10:52', '2016-11-09 03:10:52', '', 86, 'http://localhost/student/wp-content/uploads/2016/11/wood-ax.jpg', 0, 'attachment', 'image/jpeg', 0),
(89, 1, '2016-11-09 03:10:53', '2016-11-09 03:10:53', '', 'leather-satchel', '', 'inherit', 'open', 'closed', '', 'leather-satchel', '', '', '2016-11-09 03:10:53', '2016-11-09 03:10:53', '', 86, 'http://localhost/student/wp-content/uploads/2016/11/leather-satchel.jpg', 0, 'attachment', 'image/jpeg', 0),
(90, 1, '2016-11-09 03:10:55', '2016-11-09 03:10:55', '', 'nylon-tents', '', 'inherit', 'open', 'closed', '', 'nylon-tents', '', '', '2016-11-09 03:10:55', '2016-11-09 03:10:55', '', 86, 'http://localhost/student/wp-content/uploads/2016/11/nylon-tents.jpg', 0, 'attachment', 'image/jpeg', 0),
(91, 1, '2016-11-09 03:10:57', '2016-11-09 03:10:57', '', 'rustic-tools', '', 'inherit', 'open', 'closed', '', 'rustic-tools', '', '', '2016-11-09 03:10:57', '2016-11-09 03:10:57', '', 86, 'http://localhost/student/wp-content/uploads/2016/11/rustic-tools.jpg', 0, 'attachment', 'image/jpeg', 0),
(92, 1, '2016-11-09 03:10:59', '2016-11-09 03:10:59', '', 'stew-can', '', 'inherit', 'open', 'closed', '', 'stew-can', '', '', '2016-11-09 03:10:59', '2016-11-09 03:10:59', '', 86, 'http://localhost/student/wp-content/uploads/2016/11/stew-can.jpg', 0, 'attachment', 'image/jpeg', 0),
(93, 1, '2016-11-09 03:11:01', '2016-11-09 03:11:01', '', 'travel-hammock', '', 'inherit', 'open', 'closed', '', 'travel-hammock', '', '', '2016-11-09 03:11:01', '2016-11-09 03:11:01', '', 86, 'http://localhost/student/wp-content/uploads/2016/11/travel-hammock.jpg', 0, 'attachment', 'image/jpeg', 0),
(94, 1, '2016-11-09 03:11:03', '2016-11-09 03:11:03', '', 'hand-knit-toque', '', 'inherit', 'open', 'closed', '', 'hand-knit-toque', '', '', '2016-11-09 03:11:03', '2016-11-09 03:11:03', '', 86, 'http://localhost/student/wp-content/uploads/2016/11/hand-knit-toque.jpg', 0, 'attachment', 'image/jpeg', 0),
(95, 1, '2016-11-09 03:11:05', '2016-11-09 03:11:05', '', 'hiking-boots', '', 'inherit', 'open', 'closed', '', 'hiking-boots', '', '', '2016-11-09 03:11:05', '2016-11-09 03:11:05', '', 86, 'http://localhost/student/wp-content/uploads/2016/11/hiking-boots.jpg', 0, 'attachment', 'image/jpeg', 0),
(96, 1, '2016-11-09 03:11:06', '2016-11-09 03:11:06', '', 'large-thermos', '', 'inherit', 'open', 'closed', '', 'large-thermos', '', '', '2016-11-09 03:11:06', '2016-11-09 03:11:06', '', 86, 'http://localhost/student/wp-content/uploads/2016/11/large-thermos.jpg', 0, 'attachment', 'image/jpeg', 0),
(97, 1, '2016-11-09 03:11:08', '2016-11-09 03:11:08', '', 'film-cameras', '', 'inherit', 'open', 'closed', '', 'film-cameras', '', '', '2016-11-09 03:11:08', '2016-11-09 03:11:08', '', 86, 'http://localhost/student/wp-content/uploads/2016/11/film-cameras.jpg', 0, 'attachment', 'image/jpeg', 0),
(98, 1, '2016-11-09 03:11:10', '2016-11-09 03:11:10', '', 'flannel-shirt', '', 'inherit', 'open', 'closed', '', 'flannel-shirt', '', '', '2016-11-09 03:11:10', '2016-11-09 03:11:10', '', 86, 'http://localhost/student/wp-content/uploads/2016/11/flannel-shirt.jpg', 0, 'attachment', 'image/jpeg', 0),
(99, 1, '2016-11-09 03:11:12', '2016-11-09 03:11:12', '', 'gas-stove', '', 'inherit', 'open', 'closed', '', 'gas-stove', '', '', '2016-11-09 03:11:12', '2016-11-09 03:11:12', '', 86, 'http://localhost/student/wp-content/uploads/2016/11/gas-stove.jpg', 0, 'attachment', 'image/jpeg', 0),
(100, 1, '2016-11-09 03:11:14', '2016-11-09 03:11:14', '', 'beach-tent', '', 'inherit', 'open', 'closed', '', 'beach-tent-3', '', '', '2016-11-09 03:11:14', '2016-11-09 03:11:14', '', 86, 'http://localhost/student/wp-content/uploads/2016/11/beach-tent-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(101, 1, '2016-11-09 03:11:16', '2016-11-09 03:11:16', '', 'camper-van', '', 'inherit', 'open', 'closed', '', 'camper-van-3', '', '', '2016-11-09 03:11:16', '2016-11-09 03:11:16', '', 86, 'http://localhost/student/wp-content/uploads/2016/11/camper-van-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(102, 1, '2016-11-09 03:11:17', '2016-11-09 03:11:17', '', 'ceramic-mugs', '', 'inherit', 'open', 'closed', '', 'ceramic-mugs', '', '', '2016-11-09 03:11:17', '2016-11-09 03:11:17', '', 86, 'http://localhost/student/wp-content/uploads/2016/11/ceramic-mugs.jpg', 0, 'attachment', 'image/jpeg', 0),
(103, 1, '2016-11-09 03:13:37', '2016-11-09 03:13:37', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Travel Hammock', '', 'publish', 'closed', 'closed', '', 'travel-hammock', '', '', '2016-11-24 11:29:39', '2016-11-24 11:29:39', '', 0, 'http://localhost/student/?post_type=product&#038;p=103', 0, 'product', '', 0),
(104, 1, '2016-11-09 03:15:07', '2016-11-09 03:15:07', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Film Camera', '', 'publish', 'closed', 'closed', '', 'film-camera', '', '', '2016-11-24 11:29:23', '2016-11-24 11:29:23', '', 0, 'http://localhost/student/?post_type=product&#038;p=104', 0, 'product', '', 0),
(105, 1, '2016-11-09 03:34:42', '2016-11-09 03:34:42', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Rustic Tools', '', 'publish', 'closed', 'closed', '', 'rustic-tools', '', '', '2016-11-24 11:29:05', '2016-11-24 11:29:05', '', 0, 'http://localhost/student/?post_type=product&#038;p=105', 0, 'product', '', 0),
(106, 1, '2016-11-09 03:36:49', '2016-11-09 03:36:49', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Weathered Canoes', '', 'publish', 'closed', 'closed', '', 'weathered-canoes', '', '', '2016-11-24 10:59:44', '2016-11-24 10:59:44', '', 0, 'http://localhost/student/?post_type=product&#038;p=106', 0, 'product', '', 0),
(107, 1, '2016-11-09 03:37:51', '2016-11-09 03:37:51', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Wood Ax', '', 'publish', 'closed', 'closed', '', 'wood-ax', '', '', '2016-11-24 10:59:26', '2016-11-24 10:59:26', '', 0, 'http://localhost/student/?post_type=product&#038;p=107', 0, 'product', '', 0),
(108, 1, '2016-11-09 03:39:22', '2016-11-09 03:39:22', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Ceramic Mug', '', 'publish', 'closed', 'closed', '', 'ceramic-mug', '', '', '2016-11-24 10:59:13', '2016-11-24 10:59:13', '', 0, 'http://localhost/student/?post_type=product&#038;p=108', 0, 'product', '', 0),
(109, 1, '2016-11-09 03:40:30', '2016-11-09 03:40:30', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Gas Stove', '', 'publish', 'closed', 'closed', '', 'gas-stove', '', '', '2016-11-24 10:58:57', '2016-11-24 10:58:57', '', 0, 'http://localhost/student/?post_type=product&#038;p=109', 0, 'product', '', 0),
(110, 1, '2016-11-09 03:41:56', '2016-11-09 03:41:56', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Large Thermos', '', 'publish', 'closed', 'closed', '', 'large-thermos', '', '', '2016-11-24 10:58:43', '2016-11-24 10:58:43', '', 0, 'http://localhost/student/?post_type=product&#038;p=110', 0, 'product', '', 0) ;
INSERT INTO `igefiefposts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(112, 1, '2016-11-09 03:46:58', '2016-11-09 03:46:58', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Stew Can', '', 'publish', 'closed', 'closed', '', 'stew-can', '', '', '2016-11-24 10:58:23', '2016-11-24 10:58:23', '', 0, 'http://localhost/student/?post_type=product&#038;p=112', 0, 'product', '', 0),
(113, 1, '2016-11-09 03:48:18', '2016-11-09 03:48:18', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Flannel Shirt', '', 'publish', 'closed', 'closed', '', 'flannel-shirt', '', '', '2016-11-24 10:58:09', '2016-11-24 10:58:09', '', 0, 'http://localhost/student/?post_type=product&#038;p=113', 0, 'product', '', 0),
(114, 1, '2016-11-09 03:49:26', '2016-11-09 03:49:26', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Hand-Knit Toque', '', 'publish', 'closed', 'closed', '', 'hand-knit-toque', '', '', '2016-11-24 10:57:52', '2016-11-24 10:57:52', '', 0, 'http://localhost/student/?post_type=product&#038;p=114', 0, 'product', '', 0),
(115, 1, '2016-11-09 03:50:25', '2016-11-09 03:50:25', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Hiking Boots', '', 'publish', 'closed', 'closed', '', 'hiking-boots', '', '', '2016-11-24 10:57:32', '2016-11-24 10:57:32', '', 0, 'http://localhost/student/?post_type=product&#038;p=115', 0, 'product', '', 0),
(116, 1, '2016-11-09 03:51:08', '2016-11-09 03:51:08', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Leather Satchel', '', 'publish', 'closed', 'closed', '', 'leather-satchel', '', '', '2016-11-24 10:57:16', '2016-11-24 10:57:16', '', 0, 'http://localhost/student/?post_type=product&#038;p=116', 0, 'product', '', 0),
(117, 1, '2016-11-09 21:16:45', '2016-11-09 21:16:45', '<iframe style="border: 0;" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d10414.774646267038!2d-123.13632300000002!3d49.263252!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x548673c79e1ac457%3A0x3aea6428fa30dc6a!2s1490+W+Broadway%2C+Vancouver%2C+BC+V6H%2C+Canada!5e0!3m2!1sen!2sca!4v1478663734077" width="760" height="300" frameborder="0" allowfullscreen="allowfullscreen"></iframe>\r\n\r\n&nbsp;\r\n<h2>WE TAKE CAMPING VERY SERIOUSLY.</h2>\r\nInhabitent Camping Supply Co. knows what it takes to outfit a camping trip right. From flannel shirts to artisanal axes, we’ve got your covered. Please contact us below with any questions comments or suggestions.\r\n<h2>SEND US EMAIL!</h2>\r\n&nbsp;\r\n\r\n[contact-form-7 id="118" title="Contact form 1"]', 'Find Us', '', 'inherit', 'closed', 'closed', '', '23-autosave-v1', '', '', '2016-11-09 21:16:45', '2016-11-09 21:16:45', '', 23, 'http://localhost/student/2016/11/09/23-autosave-v1/', 0, 'revision', '', 0),
(118, 1, '2016-11-09 04:03:16', '2016-11-09 04:03:16', '<label> Your Name (required)\n    [text* your-name] </label>\n\n<label> Your Email (required)\n    [email* your-email] </label>\n\n<label> Subject\n    [text your-subject] </label>\n\n<label> Your Message\n    [textarea your-message] </label>\n\n[submit "Send"]\ninhabitent "[your-subject]"\n[your-name] <kiana.aghaei@gmail.com>\nFrom: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n--\nThis e-mail was sent from a contact form on inhabitent (http:/localhost:8888/inhabitent)\nkiana.aghaei@gmail.com\nReply-To: [your-email]\n\n0\n0\n\ninhabitent "[your-subject]"\ninhabitent <kiana.aghaei@gmail.com>\nMessage Body:\n[your-message]\n\n--\nThis e-mail was sent from a contact form on inhabitent (http:/localhost:8888/inhabitent)\n[your-email]\nReply-To: kiana.aghaei@gmail.com\n\n0\n0\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.', 'Contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2016-11-09 04:03:16', '2016-11-09 04:03:16', '', 0, 'http://localhost/student/?post_type=wpcf7_contact_form&p=118', 0, 'wpcf7_contact_form', '', 0),
(119, 1, '2016-11-09 04:05:12', '2016-11-09 04:05:12', '<iframe style="border: 0;" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d10414.774646267038!2d-123.13632300000002!3d49.263252!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x548673c79e1ac457%3A0x3aea6428fa30dc6a!2s1490+W+Broadway%2C+Vancouver%2C+BC+V6H%2C+Canada!5e0!3m2!1sen!2sca!4v1478663734077" width="760" height="300" frameborder="0" allowfullscreen="allowfullscreen"></iframe>\r\n\r\n&nbsp;\r\n<h2>WE TAKE CAMPING VERY SERIOUSLY.</h2>\r\nInhabitent Camping Supply Co. knows what it takes to outfit a camping trip right. From flannel shirts to artisanal axes, we’ve got your covered. Please contact us below with any questions comments or suggestions.\r\n<h2>SEND US EMAIL!</h2>\r\n&nbsp;\r\n\r\n[contact-form-7 id="118" title="Contact form 1"]', 'FIND US', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2016-11-09 04:05:12', '2016-11-09 04:05:12', '', 23, 'http://localhost/student/2016/11/09/23-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `igefiefposts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(121, 1, '2016-11-09 21:16:41', '2016-11-09 21:16:41', '<iframe style="border: 0;" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d10414.774646267038!2d-123.13632300000002!3d49.263252!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x548673c79e1ac457%3A0x3aea6428fa30dc6a!2s1490+W+Broadway%2C+Vancouver%2C+BC+V6H%2C+Canada!5e0!3m2!1sen!2sca!4v1478663734077" width="760" height="300" frameborder="0" allowfullscreen="allowfullscreen"></iframe>\r\n\r\n&nbsp;\r\n<h2>WE TAKE CAMPING VERY SERIOUSLY.</h2>\r\nInhabitent Camping Supply Co. knows what it takes to outfit a camping trip right. From flannel shirts to artisanal axes, we’ve got your covered. Please contact us below with any questions comments or suggestions.\r\n<h2>SEND US EMAIL!</h2>\r\n&nbsp;\r\n\r\n[contact-form-7 id="118" title="Contact form 1"]', 'Find Us', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2016-11-09 21:16:41', '2016-11-09 21:16:41', '', 23, 'http://localhost/student/2016/11/09/23-revision-v1/', 0, 'revision', '', 0),
(126, 1, '2016-11-14 07:11:50', '2016-11-14 07:11:50', 'Gochujang cronut authentic, cliche chicharrones food truck aesthetic whatever iPhone tousled. Paleo semiotics gastropub messenger bag, kogi beard tattooed truffaut cred artisan. Skateboard cliche selfies fashion axe, viral ugh vinyl plaid before they sold out squid jean shorts tofu letterpress. Kombucha gluten-free banh mi authentic paleo, kale chips typewriter kogi normcore mustache cliche before they sold out intelligentsia poutine 90’s. Fixie mlkshk put a bird on it messenger bag cardigan, gochujang cronut health goth tousled truffaut humblebrag keytar you probably haven’t heard of them chillwave. Put a bird on it flexitarian cornhole leggings umami. Umami polaroid gentrify distillery tacos flannel green juice.\r\n\r\nTruffaut twee master cleanse, drinking vinegar poutine +1 letterpress fanny pack. Truffaut dreamcatcher church-key 90’s bicycle rights. Actually tumblr fingerstache schlitz trust fund keffiyeh. Gastropub pitchfork jean shorts paleo, photo booth 90’s yr drinking vinegar shore ditch vice iPhone 3 wolf moon neutra craft beer taxidermy. Cronut YOLO readymade man bun, trust fund kale chips leggings four loko chia blue bottle raw denim wayfarers beard. Authentic freegan waistcoat hoodie. Hashtag dreamcatcher pickled, locavore messenger bag banh mi tousled man braid ennui.', 'HOW TO: EATING HEALTHY MEALS IN THE WILD', '', 'inherit', 'closed', 'closed', '', '66-revision-v1', '', '', '2016-11-14 07:11:50', '2016-11-14 07:11:50', '', 66, 'http://localhost/student/2016/11/14/66-revision-v1/', 0, 'revision', '', 0),
(127, 2, '2016-11-22 18:18:50', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-11-22 18:18:50', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=127', 0, 'post', '', 0),
(129, 1, '2016-11-24 10:54:00', '2016-11-24 10:54:00', 'Try-hard listicle truffaut locavore, pabst humblebrag bespoke flexitarian squid street art chia chicharrones. Gastropub portland cornhole poutine 90’s drinking vinegar, semiotics raw denim. Helvetica cornhole health goth pickled, portland banjo knausgaard drinking vinegar DIY YOLO trust fund tumblr skateboard church-key slow-carb. Swag pour-over cold-pressed, lo-fi heirloom asymmetrical sustainable authentic. Irony helvetica forage, mlkshk single-origin coffee scenester banjo jean shorts echo park hoodie ennui raw denim bitters tattooed plaid. Paleo quinoa mustache echo park, shoreditch scenester bitters chia shabby chic man braid tofu. Portland man bun scenester, wolf master cleanse iPhone selfies readymade godard sustainable asymmetrical williamsburg.\n\nHealth goth ramps cold-pressed, literally etsy lomo fashion axe brunch dreamcatcher mlkshk vegan. Dreamcatcher squid shoreditch, kogi cold-pressed paleo four loko DIY umami keffiyeh. Blog green juice tofu yr chillwave taxidermy. Kinfolk aesthetic asymmetrical, waistcoat cray fashion axe keytar pork belly truffaut narwhal post-ironic squid listicle poutine. Twee quinoa brooklyn pour-over, beard wayfarers flannel. Shoreditch meditation ramps, tofu keytar etsy plaid bespoke. Yr synth poutine, farm-to-table raw denim mixtape everyday carry brunch scenester.', 'Fireside Libations: 3 Warm Coctaile Recipes', '', 'inherit', 'closed', 'closed', '', '55-autosave-v1', '', '', '2016-11-24 10:54:00', '2016-11-24 10:54:00', '', 55, 'http://localhost/student/2016/11/24/55-autosave-v1/', 0, 'revision', '', 0),
(130, 1, '2016-11-24 10:54:02', '2016-11-24 10:54:02', 'Try-hard listicle truffaut locavore, pabst humblebrag bespoke flexitarian squid street art chia chicharrones. Gastropub portland cornhole poutine 90’s drinking vinegar, semiotics raw denim. Helvetica cornhole health goth pickled, portland banjo knausgaard drinking vinegar DIY YOLO trust fund tumblr skateboard church-key slow-carb. Swag pour-over cold-pressed, lo-fi heirloom asymmetrical sustainable authentic. Irony helvetica forage, mlkshk single-origin coffee scenester banjo jean shorts echo park hoodie ennui raw denim bitters tattooed plaid. Paleo quinoa mustache echo park, shoreditch scenester bitters chia shabby chic man braid tofu. Portland man bun scenester, wolf master cleanse iPhone selfies readymade godard sustainable asymmetrical williamsburg.\r\n\r\nHealth goth ramps cold-pressed, literally etsy lomo fashion axe brunch dreamcatcher mlkshk vegan. Dreamcatcher squid shoreditch, kogi cold-pressed paleo four loko DIY umami keffiyeh. Blog green juice tofu yr chillwave taxidermy. Kinfolk aesthetic asymmetrical, waistcoat cray fashion axe keytar pork belly truffaut narwhal post-ironic squid listicle poutine. Twee quinoa brooklyn pour-over, beard wayfarers flannel. Shoreditch meditation ramps, tofu keytar etsy plaid bespoke. Yr synth poutine, farm-to-table raw denim mixtape everyday carry brunch scenester.', 'Fireside Libations: 3 Warm Coctaile Recipes', '', 'inherit', 'closed', 'closed', '', '55-revision-v1', '', '', '2016-11-24 10:54:02', '2016-11-24 10:54:02', '', 55, 'http://localhost/student/2016/11/24/55-revision-v1/', 0, 'revision', '', 0),
(131, 1, '2016-11-24 10:54:38', '2016-11-24 10:54:38', 'Ethical tumblr gentrify listicle roof party. Normcore jean shorts single-origin coffee aesthetic, selvage williamsburg chartreuse austin banjo tumblr trust fund. Vinyl freegan trust fund, blue bottle chicharrones VHS fanny pack pop-up tumblr put a bird on it blog whatever. Authentic next level shabby chic squid. Brooklyn chicharrones fanny pack waistcoat deep v. Distillery cronut man bun, readymade gluten-free fap listicle bespoke meh cray yuccie vinyl sartorial kogi. Pickled retro organic kale chips.\r\n\r\nShabby chic bicycle rights vinyl, ugh ennui wayfarers four dollar toast. Leggings beard ennui, bushwick mixtape next level meditation master cleanse bicycle rights single-origin coffee post-ironic kogi butcher. Cold-pressed yuccie knausgaard truffaut, messenger bag blog plaid seitan pork belly chambray echo park. PBR&amp;B direct trade lomo actually quinoa. Marfa you probably haven’t heard of them fanny pack, everyday carry craft beer ethical before they sold out bespoke pabst truffaut chicharrones pitchfork synth echo park biodiesel. Kinfolk disrupt four loko plaid, tumblr cold-pressed YOLO microdosing art party stumptown hammock. Fap man braid polaroid pug.', 'Van Camping Photo Contest', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2016-11-24 10:54:38', '2016-11-24 10:54:38', '', 50, 'http://localhost/student/2016/11/24/50-revision-v1/', 0, 'revision', '', 0),
(132, 1, '2016-11-24 10:55:35', '2016-11-24 10:55:35', 'Gochujang cronut authentic, cliche chicharrones food truck aesthetic whatever iPhone tousled. Paleo semiotics gastropub messenger bag, kogi beard tattooed truffaut cred artisan. Skateboard cliche selfies fashion axe, viral ugh vinyl plaid before they sold out squid jean shorts tofu letterpress. Kombucha gluten-free banh mi authentic paleo, kale chips typewriter kogi normcore mustache cliche before they sold out intelligentsia poutine 90’s. Fixie mlkshk put a bird on it messenger bag cardigan, gochujang cronut health goth tousled truffaut humblebrag keytar you probably haven’t heard of them chillwave. Put a bird on it flexitarian cornhole leggings umami. Umami polaroid gentrify distillery tacos flannel green juice.\r\n\r\nTruffaut twee master cleanse, drinking vinegar poutine +1 letterpress fanny pack. Truffaut dreamcatcher church-key 90’s bicycle rights. Actually tumblr fingerstache schlitz trust fund keffiyeh. Gastropub pitchfork jean shorts paleo, photo booth 90’s yr drinking vinegar shore ditch vice iPhone 3 wolf moon neutra craft beer taxidermy. Cronut YOLO readymade man bun, trust fund kale chips leggings four loko chia blue bottle raw denim wayfarers beard. Authentic freegan waistcoat hoodie. Hashtag dreamcatcher pickled, locavore messenger bag banh mi tousled man braid ennui.', 'How to: Eating Healthy Meals in the Wild', '', 'inherit', 'closed', 'closed', '', '66-revision-v1', '', '', '2016-11-24 10:55:35', '2016-11-24 10:55:35', '', 66, 'http://localhost/student/2016/11/24/66-revision-v1/', 0, 'revision', '', 0),
(133, 1, '2016-11-24 10:56:00', '2016-11-24 10:56:00', 'Fashion axe schlitz selvage, art party fixie ugh skateboard fap keffiyeh intelligentsia gastropub tattooed humblebrag brunch shabby chic. Tilde selvage ennui, ethical sartorial keytar gastropub mlkshk. Migas seitan lumbersexual, paleo kogi sriracha photo booth hoodie franzen. XOXO fap master cleanse everyday carry, four loko helvetica marfa. Tousled health goth normcore, raw denim banh mi bespoke quinoa. Readymade keytar iPhone fashion axe, raw denim put a bird on it 3 wolf moon plaid fap you probably haven’t heard of them gentrify tumblr kickstarter seitan. Stumptown cold-pressed green juice, vinyl roof party mixtape gluten-free fashion axe kickstarter kitsch.\r\n\r\nKogi mixtape tousled chicharrones art party kinfolk. Synth vinyl tote bag food truck mumblecore roof party, fashion axe heirloom wolf twee butcher marfa gentrify keytar neutra. Scenester cardigan twee, gochujang butcher ugh blog before they sold out chambray sriracha cold-pressed fanny pack kitsch jean shorts. Master cleanse man bun flannel, locavore lo-fi hashtag next level wolf thundercats cronut man braid helvetica jean shorts listicle. XOXO kogi health goth, jean shorts scenester pug waistcoat shabby chic fap polaroid church-key organic brunch flexitarian. Yuccie lo-fi hammock VHS, waistcoat hashtag post-ironic gochujang helvetica paleo four loko kogi meh cray sartorial. Flexitarian paleo health goth freegan blue bottle.\r\n\r\nViral hashtag deep v, iPhone street art tacos helvetica semiotics sustainable man braid paleo affogato raw denim flexitarian mumblecore. Bicycle rights shabby chic humblebrag small batch pop-up. Slow-carb bespoke biodiesel sartorial migas fashion axe, mumblecore pop-up tumblr. Gentrify YOLO cray art party occupy, readymade wolf mustache. Food truck tacos microdosing poutine, kombucha YOLO mumblecore. Freegan typewriter distillery truffaut. Portland slow-carb hammock, yuccie cardigan before they sold out organic blog messenger bag tattooed church-key biodiesel XOXO tumblr.', 'Glamping Made Easy', '', 'inherit', 'closed', 'closed', '', '73-revision-v1', '', '', '2016-11-24 10:56:00', '2016-11-24 10:56:00', '', 73, 'http://localhost/student/2016/11/24/73-revision-v1/', 0, 'revision', '', 0),
(134, 1, '2016-11-24 10:56:26', '2016-11-24 10:56:26', 'Wayfarers VHS chambray schlitz, ramps semiotics post-ironic franzen fixie wolf polaroid viral. Blue bottle scenester paleo bitters, master cleanse put a bird on it PBR&amp;B brunch kinfolk echo park pitchfork YOLO. Forage biodiesel polaroid beard, scenester normcore actually swag food truck meggings. Readymade cornhole pabst gastropub. Roof party put a bird on it quinoa, bicycle rights kickstarter venmo master cleanse. Sustainable keffiyeh leggings, farm-to-table cliche banh mi drinking vinegar. Crucifix tote bag pork belly, before they sold out artisan YOLO listicle kombucha gluten-free vice shoreditch actually swag direct trade.\r\n\r\nVenmo XOXO meh hella raw denim. Migas listicle photo booth, wayfarers single-origin coffee artisan gastropub iPhone echo park. Banjo forage kale chips tilde semiotics echo park artisan art party, meditation viral retro pitchfork. Seitan tacos cray waistcoat, migas pickled fap try-hard gentrify narwhal pinterest thundercats keffiyeh. Keffiyeh hashtag tofu slow-carb, yr pork belly VHS normcore typewriter gastropub letterpress echo park. Ugh sriracha messenger bag umami, mixtape vice flexitarian forage iPhone synth sustainable banjo. Banh mi humblebrag shoreditch, single-origin coffee butcher skateboard farm-to-table bicycle rights.', '5 Tips For Solo Camping', '', 'inherit', 'closed', 'closed', '', '70-revision-v1', '', '', '2016-11-24 10:56:26', '2016-11-24 10:56:26', '', 70, 'http://localhost/student/2016/11/24/70-revision-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `igefiefposts`
# --------------------------------------------------------



#
# Delete any existing table `igefiefterm_relationships`
#

DROP TABLE IF EXISTS `igefiefterm_relationships`;


#
# Table structure of table `igefiefterm_relationships`
#

CREATE TABLE `igefiefterm_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `igefiefterm_relationships`
#
INSERT INTO `igefiefterm_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(10, 10, 0),
(46, 2, 0),
(47, 2, 0),
(49, 2, 0),
(50, 3, 0),
(50, 4, 0),
(50, 12, 0),
(55, 5, 0),
(55, 6, 0),
(55, 7, 0),
(66, 5, 0),
(66, 13, 0),
(66, 14, 0),
(70, 15, 0),
(70, 16, 0),
(73, 15, 0),
(73, 16, 0),
(73, 17, 0),
(75, 1, 0),
(80, 2, 0),
(81, 10, 0),
(86, 10, 0),
(103, 10, 0),
(104, 8, 0),
(105, 8, 0),
(106, 8, 0),
(107, 8, 0),
(108, 9, 0),
(109, 9, 0),
(110, 9, 0),
(112, 9, 0),
(113, 11, 0),
(114, 11, 0),
(115, 11, 0),
(116, 11, 0) ;

#
# End of data contents of table `igefiefterm_relationships`
# --------------------------------------------------------



#
# Delete any existing table `igefiefterm_taxonomy`
#

DROP TABLE IF EXISTS `igefiefterm_taxonomy`;


#
# Table structure of table `igefiefterm_taxonomy`
#

CREATE TABLE `igefiefterm_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `igefiefterm_taxonomy`
#
INSERT INTO `igefiefterm_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'nav_menu', '', 0, 4),
(3, 3, 'post_tag', '', 0, 1),
(4, 4, 'post_tag', '', 0, 1),
(5, 5, 'category', '', 0, 2),
(6, 6, 'post_tag', '', 0, 1),
(7, 7, 'post_tag', '', 0, 1),
(8, 8, 'product_type', 'Get back to nature with all the tools and toys you need to enjoy the great outdoors.', 0, 4),
(9, 9, 'product_type', 'Nothing beats food cooked over a fire. We have all you need for good camping eats.', 0, 4),
(10, 10, 'product_type', 'Get a good night’s rest in the wild in a home away from home that travels well.', 0, 4),
(11, 11, 'product_type', 'From flannel shirts to toques, look the part while roughing it in the great outdoors.', 0, 4),
(12, 12, 'category', '', 0, 1),
(13, 13, 'post_tag', '', 0, 1),
(14, 14, 'post_tag', '', 0, 1),
(15, 15, 'category', '', 0, 2),
(16, 16, 'post_tag', '', 0, 2),
(17, 17, 'category', '', 0, 1) ;

#
# End of data contents of table `igefiefterm_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `igefieftermmeta`
#

DROP TABLE IF EXISTS `igefieftermmeta`;


#
# Table structure of table `igefieftermmeta`
#

CREATE TABLE `igefieftermmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `igefieftermmeta`
#

#
# End of data contents of table `igefieftermmeta`
# --------------------------------------------------------



#
# Delete any existing table `igefiefterms`
#

DROP TABLE IF EXISTS `igefiefterms`;


#
# Table structure of table `igefiefterms`
#

CREATE TABLE `igefiefterms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `igefiefterms`
#
INSERT INTO `igefiefterms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Menu 1', 'menu-1', 0),
(3, 'photography', 'photography', 0),
(4, 'vans', 'vans', 0),
(5, 'Recipes', 'recipes', 0),
(6, 'campfires', 'campfires', 0),
(7, 'drinks', 'drinks', 0),
(8, 'Do', 'do', 0),
(9, 'Eat', 'eat', 0),
(10, 'Sleep', 'sleep', 0),
(11, 'Wear', 'wear', 0),
(12, 'Contests', 'contests', 0),
(13, 'food', 'food', 0),
(14, 'healthy', 'healthy', 0),
(15, 'How-Tos', 'how-tos', 0),
(16, 'tenting', 'tenting', 0),
(17, 'Not Really Camping', 'not-really-camping', 0) ;

#
# End of data contents of table `igefiefterms`
# --------------------------------------------------------



#
# Delete any existing table `igefiefusermeta`
#

DROP TABLE IF EXISTS `igefiefusermeta`;


#
# Table structure of table `igefiefusermeta`
#

CREATE TABLE `igefiefusermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `igefiefusermeta`
#
INSERT INTO `igefiefusermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'kiana'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'igefiefcapabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'igefiefuser_level', '10'),
(12, 1, 'dismissed_wp_pointers', ''),
(13, 1, 'show_welcome_panel', '1'),
(15, 1, 'igefiefdashboard_quick_press_last_post_id', '127'),
(17, 1, 'closedpostboxes_product_type', 'a:0:{}'),
(18, 1, 'closedpostboxes_product_type', 'a:0:{}'),
(19, 1, 'closedpostboxes_product_type', 'a:0:{}'),
(20, 1, 'metaboxhidden_product_type', 'a:1:{i:0;s:7:"slugdiv";}'),
(21, 1, 'closedpostboxes_product_type', 'a:0:{}'),
(22, 1, 'closedpostboxes_cfs', 'a:0:{}'),
(23, 1, 'metaboxhidden_cfs', 'a:1:{i:0;s:7:"slugdiv";}'),
(24, 1, 'meta-box-order_product', 'a:3:{s:4:"side";s:55:"submitdiv,cfs_input_8,tagsdiv-product_type,postimagediv";s:6:"normal";s:18:"postcustom,slugdiv";s:8:"advanced";s:0:"";}'),
(25, 1, 'screen_layout_product', '2'),
(27, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(28, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(31, 1, 'igefiefuser-settings', 'libraryContent=browse&editor=tinymce&mfold=o'),
(32, 1, 'igefiefuser-settings-time', '1479117736'),
(33, 1, 'nav_menu_recently_edited', '2'),
(34, 1, 'session_tokens', 'a:2:{s:64:"82cea250cc9db459d7e21505a6bc19a313d03699e74a3fc90d6ac1b9d0a86cb9";a:4:{s:10:"expiration";i:1480233017;s:2:"ip";s:3:"::1";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36";s:5:"login";i:1479023417;}s:64:"650daccc535fe3cc5c1c2be0a85119127d31e346ec1b0b2cb8c69a5521671f82";a:4:{s:10:"expiration";i:1480161795;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.98 Safari/537.36";s:5:"login";i:1479988995;}}'),
(35, 1, 'closedpostboxes_page', 'a:0:{}'),
(36, 1, 'metaboxhidden_page', 'a:7:{i:0;s:12:"cfs_input_59";i:1;s:12:"revisionsdiv";i:2;s:10:"postcustom";i:3;s:16:"commentstatusdiv";i:4;s:11:"commentsdiv";i:5;s:7:"slugdiv";i:6;s:9:"authordiv";}'),
(37, 2, 'nickname', 'mandi'),
(38, 2, 'first_name', ''),
(39, 2, 'last_name', ''),
(40, 2, 'description', ''),
(41, 2, 'rich_editing', 'true'),
(42, 2, 'comment_shortcuts', 'false'),
(43, 2, 'admin_color', 'fresh'),
(44, 2, 'use_ssl', '0'),
(45, 2, 'show_admin_bar_front', 'true'),
(46, 2, 'igefiefcapabilities', 'a:1:{s:13:"administrator";b:1;}'),
(47, 2, 'igefiefuser_level', '10'),
(48, 2, 'dismissed_wp_pointers', ''),
(50, 2, 'igefiefdashboard_quick_press_last_post_id', '127') ;

#
# End of data contents of table `igefiefusermeta`
# --------------------------------------------------------



#
# Delete any existing table `igefiefusers`
#

DROP TABLE IF EXISTS `igefiefusers`;


#
# Table structure of table `igefiefusers`
#

CREATE TABLE `igefiefusers` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `igefiefusers`
#
INSERT INTO `igefiefusers` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'kiana', '$P$BxregssrlP8i0sKj82WwH59EAuEITM0', 'kiana', 'kiana.aghaei@gmail.com', '', '2016-11-07 09:23:55', '', 0, 'kiana'),
(2, 'mandi', '$P$B5zP1DnoYK4fXgOqQ2c52nAKbHlnYd.', 'mandi', 'mandi@redacademy.com', '', '2016-11-14 15:18:16', '1479136697:$P$B/Uw8lL/Zdo3vwt3Cm1iYIWv131fiv0', 0, 'mandi') ;

#
# End of data contents of table `igefiefusers`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

